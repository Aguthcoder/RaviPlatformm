"use client";

import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useState, Suspense } from "react";
import LoadingScreen from "./LoadingScreen";

function ClientShellContent({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // فعال کردن لودینگ هنگام تغییر مسیر
    setIsLoading(true);
    const timeout = setTimeout(() => {
      setIsLoading(false);
    }, 800); // تاخیر مصنوعی برای نمایش انیمیشن

    return () => clearTimeout(timeout);
  }, [pathname, searchParams]);

  return (
    <>
      {isLoading && <LoadingScreen />}
      {children}
    </>
  );
}

export default function ClientShell({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <ClientShellContent>{children}</ClientShellContent>
    </Suspense>
  );
}
