"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  User, 
  Gamepad2, 
  Bell, 
  Wallet, 
  UserPlus, 
  LogOut, 
  Home,
  LayoutDashboard
} from "lucide-react";

interface SidebarProps {
  isMobile?: boolean;
  onClose?: () => void;
}

export default function Sidebar({ isMobile, onClose }: SidebarProps) {
  const pathname = usePathname();

  const menuItems = [
    { name: "داشبورد", href: "/dashboard", icon: LayoutDashboard },
    { name: "پروفایل من", href: "/dashboard/profile", icon: User },
    { name: "کیف پول", href: "/dashboard/wallet", icon: Wallet },
    { name: "بازی‌ها", href: "/dashboard/games", icon: Gamepad2 },
    { name: "دعوت از دوستان", href: "/dashboard/invite", icon: UserPlus },
    { name: "اعلان‌ها", href: "/dashboard/notifications", icon: Bell },
  ];

  return (
    <div className={`h-full flex flex-col bg-navy-900 text-white border-l border-navy-800 ${isMobile ? 'p-4' : 'p-6'}`}>
      {/* هدر سایدبار */}
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="w-10 h-10 bg-raavi-orange rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-orange-500/20">
          R
        </div>
        <div>
          <h1 className="font-black text-2xl tracking-tight">راوی</h1>
          <span className="text-xs text-slate-400">پنل کاربری</span>
        </div>
      </div>

      {/* منوی اصلی */}
      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all duration-200 group ${
                isActive 
                  ? "bg-raavi-orange text-white shadow-lg shadow-orange-500/20 font-bold" 
                  : "text-slate-400 hover:bg-navy-800 hover:text-white"
              }`}
            >
              <Icon size={20} className={isActive ? "stroke-[2.5]" : "stroke-[1.5]"} />
              <span className="text-sm">{item.name}</span>
              {isActive && (
                <div className="mr-auto w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* بخش پایین سایدبار */}
      <div className="mt-auto pt-6 border-t border-navy-800 space-y-3">
        {/* دکمه بازگشت به خانه (ویژه دسکتاپ و موبایل) */}
        <Link
          href="/events"
          className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-navy-800 text-raavi-orange hover:bg-navy-700 transition-colors font-bold border border-navy-700 hover:border-raavi-orange/50"
        >
          <Home size={20} />
          <span className="text-sm">رزرو همنشینی</span>
        </Link>

        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-colors text-sm font-medium">
          <LogOut size={20} />
          <span>خروج از حساب</span>
        </button>
      </div>
    </div>
  );
}
