"use client";

import { Copy, Share2 } from "lucide-react";

export default function InvitePage() {
  return (
    <div className="max-w-xl mx-auto text-center space-y-8 pt-8">
        <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mx-auto text-raavi-orange mb-4">
            <Share2 size={40} />
        </div>
        <h1 className="text-2xl font-black text-navy-900">دوستانت رو دعوت کن!</h1>
        <p className="text-slate-500">
            با دعوت هر دوست، ۲۰ هزار تومان اعتبار هدیه بگیر و به دوستت هم ۲۰ هزار تومان هدیه بده.
        </p>

        <div className="bg-white border-2 border-dashed border-slate-300 rounded-2xl p-6 relative">
            <div className="text-xs text-slate-400 uppercase tracking-widest mb-2 font-bold">کد معرف شما</div>
            <div className="text-3xl font-black text-navy-900 tracking-widest" dir="ltr">RAAVI-9821</div>
            <button className="absolute top-1/2 -translate-y-1/2 left-6 p-2 bg-slate-100 rounded-lg hover:bg-raavi-orange hover:text-white transition">
                <Copy size={20}/>
            </button>
        </div>

        <button className="w-full bg-navy-900 text-white font-bold py-4 rounded-2xl shadow-xl shadow-navy-900/20 hover:bg-navy-800 transition">
            اشتراک گذاری لینک دعوت
        </bu>
    </div>
  );
}
