"use client";

import { useState } from "react";
import { Menu, X } from "lucide-react";
import Sidebar from "@/components/Sidebar";
import BottomNavbar from "@/components/BottomNavbar";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden font-vazir">
      {/* سایدبار دسکتاپ */}
      <div className="hidden lg:block w-72 h-full flex-shrink-0">
        <Sidebar />
      </div>

      {/* لایه تاریک موبایل */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-navy-900/80 backdrop-blur-sm z-[998] lg:hidden transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* سایدبار موبایل */}
      <div
        className={`fixed top-0 right-0 bottom-0 w-72 z-[999] bg-navy-900 lg:hidden transition-transform duration-300 ease-out ${
          isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <button
          onClick={() => setIsMobileMenuOpen(false)}
          className="absolute top-4 left-4 z-[1000] bg-white/10 hover:bg-white/20 text-white rounded-full p-2 backdrop-blur"
        >
          <X size={20} />
        </button>
        <Sidebar isMobile={true} onClose={() => setIsMobileMenuOpen(false)} />
      </div>

      {/* محتوای اصلی */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* هدر موبایل */}
        <header className="lg:hidden h-16 bg-white/80 backdrop-blur border-b border-slate-200 flex items-center justify-between px-4 flex-shrink-0 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="text-navy-900 p-2 -mr-2 hover:bg-slate-100 rounded-xl transition"
            >
              <Menu size={24} />
            </button>
            <span className="font-black text-xl text-navy-900">راوی</span>
          </div>
          <div className="w-9 h-9 bg-navy-900 rounded-full flex items-center justify-center text-white font-bold text-xs border-2 border-raavi-orange">
            U
          </div>
        </header>

        {/* ناحیه اسکرول محتوا */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth pb-24 lg:pb-8">
          <div className="max-w-5xl mx-auto">
             {children}
          </div>
        </div>

        {/* نوار پایین (فقط در موبایل) */}
        <div className="lg:hidden">
            <BottomNavbar />
        </div>
      </main>
    </div>
  );
}
