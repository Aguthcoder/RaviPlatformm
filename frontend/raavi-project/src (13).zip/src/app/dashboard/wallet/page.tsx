"use client";

import { Wallet, CreditCard, History, Plus } from "lucide-react";

export default function WalletPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black text-navy-900">کیف پول من</h1>
      
      <div className="bg-gradient-to-r from-navy-900 to-navy-700 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="relative z-10">
            <div className="text-slate-300 mb-2 text-sm">موجودی فعلی</div>
            <div className="text-4xl font-black mb-8 tracking-tight">۲۵۰,۰۰۰ <span className="text-lg font-normal opacity-80">تومان</span></div>
            
            <div className="flex gap-3">
                <button className="flex-1 bg-raavi-orange hover:bg-orange-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition">
                    <Plus size={18}/> افزایش موجودی
                </button>
                <button className="flex-1 bg-white/10 hover:bg-white/20 text-white py-3 rounded-xl font-bold transition backdrop-blur">
                   برداشت وجه
                </button>
            </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 border border-slate-100">
        <h3 className="font-bold text-navy-900 mb-4 flex items-center gap-2">
            <History size={20} className="text-slate-400"/>
            تراکنش‌های اخیر
        </h3>
        <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                        <Plus size={16}/>
                    </div>
                    <div>
                        <div className="font-bold text-sm text-navy-900">شارژ حساب</div>
                        <div className="text-xs text-slate-400">۱۴۰۳/۱۱/۲۳ - ۱۲:۳۰</div>
                    </div>
                </div>
                <div className="font-bold text-green-600 text-sm">+ ۱۰۰,۰۰۰</div>
            </div>
             <div className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                        <CreditCard size={16}/>
                    </div>
                    <div>
                        <div className="font-bold text-sm text-navy-900">رزرو کافه بازی</div>
                        <div className="text-xs text-slate-400">۱۴۰۳/۱۱/۲۰ - ۱۸:۰۰</div>
                    </div>
                </div>
                <div className="font-bold text-red-600 text-sm">- ۵۰,۰۰۰</div>
            </div>
        </div>
      </div>
    </div>
  );
}
