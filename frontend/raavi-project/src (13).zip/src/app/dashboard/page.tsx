"use client";

import { Calendar, Clock, ArrowLeft, Wallet, Star } from "lucide-react";
import Link from "next/link";

export default function DashboardPage() {
  const upcomingEvents = [
    {
      id: 1,
      title: "قرار صبحانه (همنشین)",
      date: "جمعه، ۲۴ بهمن",
      time: "۱۰:۰۰ صبح",
      location: "کافه لمیز، ولیعصر",
      match: 95,
      status: "confirmed",
      image: "bg-gradient-to-br from-orange-400 to-red-500"
    },
    {
      id: 2,
      title: "مافیا (همبازی)",
      date: "پنجشنبه، ۲۳ بهمن",
      time: "۱۸:۰۰ عصر",
      location: "گیم‌کلاب مرکز",
      match: 88,
      status: "pending",
      image: "bg-gradient-to-br from-slate-700 to-slate-900"
    }
  ];

  return (
    <div className="space-y-8">
      {/* هدر خوش‌آمدگویی */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-navy-900 mb-2">
            سلام، کاربر عزیز 👋
          </h1>
          <p className="text-slate-500">
            امروز چه برنامه‌ای برای همنشینی داری؟
          </p>
        </div>
        
        {/* ویجت کیف پول */}
        <div className="bg-white p-2 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3 px-4 w-full md:w-auto">
            <div className="bg-orange-100 p-2 rounded-xl text-raavi-orange">
                <Wallet size={20} />
            </div>
            <div className="flex-1">
                <div className="text-xs text-slate-400">موجودی کیف پول</div>
                <div className="text-sm font-bold text-navy-900">۲۵۰,۰۰۰ تومان</div>
            </div>
            <Link href="/dashboard/wallet" className="bg-navy-900 text-white text-xs px-3 py-1.5 rounded-lg hover:bg-raavi-orange transition-colors">
                افزایش
            </Link>
        </div>
      </div>

      {/* بخش رویدادهای من */}
      <div>
        <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-navy-900 flex items-center gap-2">
                <Calendar className="text-raavi-orange" size={20}/>
                برنامه‌های پیش‌رو
            </h2>
            <Link href="/events" className="text-sm text-raavi-orange font-bold hover:underline">
                مشاهده همه
            </Link>
        </div>

        {upcomingEvents.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-4">
                {upcomingEvents.map(evt => (
                    <div key={evt.id} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex gap-4 items-center">
                        <div className={`w-20 h-20 rounded-2xl ${evt.image} flex items-center justify-center text-white font-bold text-2xl shadow-inner shrink-0`}>
                            {evt.title.charAt(0)}
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start mb-1">
                                <h3 className="font-bold text-navy-900 text-sm">{evt.title}</h3>
                                {evt.status === 'confirmed' && (
                                    <span className="bg-green-100 text-green-700 text-[10px] px-2 py-0.5 rounded-full font-bold whitespace-nowrap">قطعی شده</span>
                                )}
                                {evt.status === 'pending' && (
                                    <span className="bg-orange-100 text-orange-700 text-[10px] px-2 py-0.5 rounded-full font-bold whitespace-nowrap">در انتظار</span>
                                )}
                            </div>
                            <div className="text-xs text-slate-500 flex flex-wrap items-center gap-3 mb-3">
                                <span className="flex items-center gap-1"><Calendar size={12}/> {evt.date}</span>
                                <span className="flex items-center gap-1"><Clock size={12}/> {evt.time}</span>
                            </div>
                            <div className="flex items-center gap-1 text-xs font-medium text-navy-600 bg-slate-50 px-2 py-1 rounded-lg w-fit">
                                <Star size={12} className="text-raavi-orange fill-raavi-orange"/>
                                {evt.match}٪ تطابق
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        ) : (
            <div className="bg-slate-50 rounded-3xl p-8 text-center border-2 border-dashed border-slate-200">
                <p className="text-slate-500 mb-4">هنوز هیچ همنشینی فعالی نداری</p>
                <Link href="/events" className="inline-flex items-center gap-2 bg-raavi-orange text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-orange-500/20 hover:-translate-y-1 transition-all">
                    رزرو اولین همنشینی
                    <ArrowLeft size={18} />
                </Link>
            </div>
        )}
      </div>

      {/* میانبرها */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
            { title: "نتایج تست", icon: "📊", link: "/dashboard/profile" },
            { title: "پیام‌ها", icon: "💬", link: "/chat" },
            { title: "پشتیبانی", icon: "🎧", link: "#" },
            { title: "قوانین", icon: "⚖️", link: "#" },
        ].map((item, idx) => (
            <Link key={idx} href={item.link} className="bg-white p-4 rounded-2xl border border-slate-100 flex flex-col items-center gap-2 hover:border-raavi-orange transition-colors group">
                <span className="text-2xl group-hover:scale-110 transition-transform">{item.icon}</span>
                <span className="text-sm font-bold text-navy-800">{item.t}</span>
            </Link>
        ))}
      </div>
    </div>
  );
}
