"use client";

import { useRouter } from "next/navigation";
import { MessageCircle, Users, Footprints, Heart, GraduationCap, Briefcase, Lightbulb, Dumbbell, Home } from "lucide-react";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import BottomNavbar from "@/components/BottomNavbar";

export default function EventsPage() {
  const router = useRouter();

  const categories = [
    { id: "hamnesheen", title: "همنشین", icon: Users, active: true },
    { id: "hamsohbat", title: "هم‌صحبت", icon: MessageCircle, active: true },
    { id: "hampa", title: "همپا", icon: Footprints, active: true },
    { id: "hamya", title: "همیا", icon: Heart, active: false },
    { id: "hamamouz", title: "هم آموز", icon: GraduationCap, active: false },
    { id: "hamkar", title: "همکار", icon: Briefcase, active: false },
    { id: "hamfekar", title: "همفکر", icon: Lightbulb, active: false },
    { id: "hamtamreen", title: "همتمرین", icon: Dumbbell, active: false },
    { id: "hamkhane", title: "همخانه", icon: Home, active: false },
  ];

  const handleCategoryClick = (id: string, active: boolean, title: string) => {
    if (active) {
      router.push(`/events/category/${id}`);
    } else {
      alert(`دسته "${title}" هنوز فعال نشده است، اما پیش‌رزرو شما ثبت شد.`);
    }
  };

  return (
    <div className="min-h-screen pb-24 pt-8 px-4 relative bg-slate-50">
      <BackgroundBlobs />
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-black text-navy-900 mb-2">
            دسته‌بندی‌ها
          </h1>
          <p className="text-slate-600">چه نوع همنشینی را جستجو می‌کنید؟</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {categories.map((cat) => {
             const Icon = cat.icon;
             return (
               <button
                 key={cat.id}
                 onClick={() => handleCategoryClick(cat.id, cat.active, cat.title)}
                 className={`flex flex-col items-center justify-center p-6 rounded-3xl transition-all duration-300 ${
                    cat.active 
                    ? "bg-navy-900 text-white shadow-xl shadow-navy-900/20 hover:-translate-y-1 hover:bg-raavi-orange" 
                    : "bg-white text-slate-400 border border-slate-200 cursor-default opacity-80"
                 }`}
               >
                 <div className={`p-4 rounded-full mb-3 ${cat.active ? "bg-white/10" : "bg-slate-100"}`}>
                    <Icon size={32} strokeWidth={2} />
                 </div>
                 <span className="font-bold text-lg">{cat.title}</span>
                 {!cat.active && <span className="text-[10px] mt-1 bg-slate-100 px-2 py-0.5 rounded-full">پیش‌رزرو</span>}
               </button>
             )
          })}
        </div>
      </div>
      <BottomNavbar />
    </div>
  );
}
