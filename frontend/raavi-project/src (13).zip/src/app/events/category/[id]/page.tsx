"use client";

import { use } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Calendar, Users, MapPin } from "lucide-react";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import BottomNavbar from "@/components/BottomNavbar";

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  capacity: number;
  registered: number;
  price: number;
  category: string;
}

// داده‌های نمونه همنشینی‌ها
const sampleEvents: { [key: string]: Event[] } = {
  hamnesheen: [
    {
      id: "1",
      title: "قدم زدن در پارک لاله",
      date: "۱۴۰۴/۰۲/۲۰",
      time: "۱۷:۰۰",
      location: "پارک لاله، تهران",
      capacity: 20,
      registered: 15,
      price: 50000,
      category: "همنشین",
    },
    {
      id: "2",
      title: "کافه و گپ‌زدن",
      date: "۱۴۰۴/۰۲/۲۲",
      time: "۱۸:۳۰",
      location: "کافه نادری، تهران",
      capacity: 15,
      registered: 12,
      price: 75000,
      category: "همنشین",
    },
    {
      id: "3",
      title: "بازی بردگیم",
      date: "۱۴۰۴/۰۲/۲۵",
      time: "۱۹:۰۰",
      location: "کافه بازی ایده، تهران",
      capacity: 12,
      registered: 8,
      price: 100000,
      category: "همنشین",
    },
  ],
  hamsohbat: [
    {
      id: "4",
      title: "بحث کتاب ماهانه",
      date: "۱۴۰۴/۰۲/۲۱",
      time: "۱۸:۰۰",
      location: "کتابخانه ملی، تهران",
      capacity: 25,
      registered: 18,
      price: 40000,
      category: "هم‌صحبت",
    },
  ],
  hampa: [
    {
      id: "5",
      title: "کوهنوردی دربند",
      date: "۱۴۰۴/۰۲/۲۳",
      time: "۰۷:۰۰",
      location: "پل دربند، تهران",
      capacity: 30,
      registered: 25,
      price: 120000,
      category: "همپا",
    },
  ],
};

const categoryTitles: { [key: string]: string } = {
  hamnesheen: "همنشین",
  hamsohbat: "هم‌صحبت",
  hampa: "همپا",
};

export default function CategoryPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const router = useRouter();
  const categoryId = resolvedParams.id;
  const events = sampleEvents[categoryId] || [];
  const categoryTitle = categoryTitles[categoryId] || "همنشینی";

  const handleBooking = (eventId: string) => {
    router.push(`/events/${eventId}/booking`);
  };

  return (
    <div className="min-h-screen pb-24 pt-8 px-4 relative">
      <BackgroundBlobs />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-slate-600 hover:text-navy-900 mb-4 transition"
          >
            <ArrowRight size={20} />
            <span className="font-medium">بازگشت</span>
          </button>

          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            {categoryTitle}
          </h1>
          <p className="text-slate-600">
            همنشینی‌های {categoryTitle} را انتخاب و رزرو کن
          </p>
        </div>

        {/* Events List */}
        {events.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {events.map((event) => {
              const waitingCount = event.capacity - event.registered;

              return (
                <div
                  key={event.id}
                  className="bg-navy-800 rounded-3xl p-6 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1"
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <span className="text-raavi-orange text-sm font-bold">
                        {event.category}
                      </span>
                      <h3 className="text-white font-black text-2xl mt-1 font-estedad">
                        {event.title}
                      </h3>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Calendar size={18} className="text-raavi-orange" />
                      <span>
                        {event.date} ساعت {event.time}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <MapPin size={18} className="text-raavi-orange" />
                      <span className="line-clamp-1">{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Users size={18} className="text-raavi-orange" />
                      <span className="text-white font-bold">
                        {waitingCount} نفر منتظر همنشینی شما هستند
                      </span>
                    </div>
                  </div>

                  {/* Price & CTA */}
                  <div className="flex items-center justify-between">
                    <div className="text-white">
                      <span className="text-3xl font-black font-estedad">
                        {event.price.toLocaleString("fa-IR")}
                      </span>
                      <span className="text-slate-400 mr-1">تومان</span>
                    </div>

                    <button
                      onClick={() => handleBooking(event.id)}
                      className="bg-raavi-orange hover:bg-raavi-600 text-white font-bold px-6 py-3 rounded-2xl transition-all hover:-translate-y-0.5"
                    >
                      رزرو همنشینی
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📅</div>
            <h3 className="text-2xl font-bold text-navy-900 mb-2">
              همنشینی جدیدی یافت نشد
            </h3>
            <p className="text-slate-600">
              به زودی همنشینی‌های جدید اضافه می‌شوند
            </p>
          </div>
        )}
      </div>

      <BottomNavbar />
    </div>
  );
}
