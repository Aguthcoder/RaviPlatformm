"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import LoadingScreen from "@/components/LoadingScreen";

export default function TestPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  // Sliders for psychology questions
  const [answers, setAnswers] = useState({
    extrovert: 50, // درونگرا - برونگرا
    logic: 50,     // احساسی - منطقی
    planning: 50,  // منعطف - بابرنامه
    risk: 50       // محتاط - ریسک‌پذیر
  });

  const handleFinish = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    // Save to local storage or backend context
    localStorage.setItem("hasCompletedTest", "true");
    router.push("/events"); // Redirect to reserve page
  };

  if(loading) return <LoadingScreen message="تحلیل شخصیت شما..." />;

  return (
    <div className="min-h-screen bg-navy-900 text-white p-6 flex flex-col items-center justify-center">
        <div className="w-full max-w-lg">
            <h1 className="text-3xl font-black text-raavi-orange mb-8 text-center">شناخت شخصیت</h1>
            
            <div className="bg-navy-800 p-6 rounded-3xl border border-navy-700 space-y-8">
                {/* Question 1 */}
                <div className="space-y-2">
                    <div className="flex justify-between text-sm font-bold text-slate-300">
                        <span>درون‌گرا</span>
                        <span>برون‌گرا</span>
                    </div>
                    <input 
                        type="range" min="0" max="100" 
                        value={answers.extrovert}
                        onChange={(e) => setAnswers({...answers, extrovert: parseInt(e.target.value)})}
                        className="w-full h-2 bg-navy-900 rounded-lg appearance-none cursor-pointer accent-raavi-orange"
                    />
                </div>

                {/* Question 2 */}
                <div className="space-y-2">
                    <div className="flex justify-between text-sm font-bold text-slate-300">
                        <span>احساسی</span>
                        <span>منطقی</span>
                    </div>
                    <input 
                        type="range" min="0" max="100" 
                        value={answers.logic}
                        onChange={(e) => setAnswers({...answers, logic: parseInt(e.target.value)})}
                        className="w-full h-2 bg-navy-900 rounded-lg appearance-none cursor-pointer accent-raavi-orange"
                    />
                </div>

                 {/* Question 3 */}
                 <div className="space-y-2">
                    <div className="flex justify-between text-sm font-bold text-slate-300">
                        <span>بداهه</span>
                        <span>برنامه‌ریزی</span>
                    </div>
                    <input 
                        type="range" min="0" max="100" 
                        value={answers.planning}
                        onChange={(e) => setAnswers({...answers, planning: parseInt(e.target.value)})}
                        className="w-full h-2 bg-navy-900 rounded-lg appearance-none cursor-pointer accent-raavi-orange"
                    />
                </div>

                <button onClick={handleFinish} className="w-full bg-raavi-orange py-4 rounded-2xl font-bold text-lg shadow-lg shadow-orange-500/20 hover:scale-105 transition mt-8">
                    ثبت و مشاهده همنشین‌ها
                </button>
            </div>
        </div>
    </div>
  );
}
