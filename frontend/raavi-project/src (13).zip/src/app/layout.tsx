import type { Metadata } from "next";
import "./globals.css";
import ClientShell from "@/components/ClientShell";
import BackgroundBlobs from "@/components/BackgroundBlobs";

export const metadata: Metadata = {
  title: "Raavi Platform",
  description: "Social Platform",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl">
      <body className="font-vazir bg-navy-50">
        <ClientShell>
          <BackgroundBlobs />
          {children}
        </ClientShell>
      </body>
    </html>
  );
}
