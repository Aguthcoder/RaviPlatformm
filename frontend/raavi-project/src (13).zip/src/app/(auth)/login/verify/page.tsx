"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAppContext } from "@/context/AppContext";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import LoadingScreen from "@/components/LoadingScreen";
import BackgroundBlobs from "@/components/BackgroundBlobs";

export default function VerifyPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { dispatch } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const phone = searchParams.get("phone") || "";

  useEffect(() => {
    // Focus on first input on mount
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return; // Only allow single digit

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 6);
    const newOtp = [...otp];

    for (let i = 0; i < pastedData.length; i++) {
      if (i < 6) {
        newOtp[i] = pastedData[i];
      }
    }

    setOtp(newOtp);

    // Focus the last filled input
    const lastIndex = Math.min(pastedData.length, 5);
    inputRefs.current[lastIndex]?.focus();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const otpCode = otp.join("");

    if (otpCode.length !== 6) return;

    setLoading(true);

    // شبیه‌سازی تایید کد
    await new Promise((resolve) => setTimeout(resolve, 1500));

    dispatch({ type: "LOGIN" });
    router.push("/test");
  };

  const handleResend = async () => {
    // شبیه‌سازی ارسال مجدد کد
    alert("کد مجدداً ارسال شد");
  };

  if (loading) {
    return <LoadingScreen message="در حال تایید..." />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <BackgroundBlobs />

      <div className="w-full max-w-md relative z-10">
        {/* لوگو و برگشت */}
        <div className="text-center mb-8">
          <Link
            href="/login"
            className="inline-flex items-center gap-2 text-slate-600 hover:text-navy-800 mb-4 transition"
          >
            <ArrowRight size={18} />
            <span className="font-medium">بازگشت</span>
          </Link>
          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            کد تایید
          </h1>
          <p className="text-slate-600">
            کد ۶ رقمی ارسال شده به شماره <span className="font-bold text-navy-800" dir="ltr">{phone}</span> را وارد کنید
          </p>
        </div>

        {/* فرم */}
        <div className="bg-navy-800 rounded-3xl shadow-2xl border border-navy-700 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* OTP Inputs */}
            <div className="flex justify-center gap-2" dir="ltr">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => {
                    inputRefs.current[index] = el;
                  }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  onPaste={handlePaste}
                  className="w-12 h-14 text-center text-2xl font-bold rounded-xl bg-navy-900 border-2 border-navy-700 focus:border-raavi-orange outline-none transition text-white"
                />
              ))}
            </div>

            {/* دکمه تایید */}
            <button
              type="submit"
              disabled={otp.join("").length !== 6}
              className="w-full bg-raavi-orange hover:bg-raavi-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-raavi-500/30 transition-all hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
            >
              تایید و ورود
            </button>

            {/* ارسال مجدد */}
            <button
              type="button"
              onClick={handleResend}
              className="w-full text-raavi-orange hover:text-raavi-400 font-bold transition"
            >
              ارسال مجدد کد
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
