import { ReactNode } from "react";
import Sidebar from "@/components/Sidebar"; // استفاده از کامپوننت جداگانه
import { Menu, Bell, Search } from "lucide-react";

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    // h-screen و overflow-hidden روی والد اصلی باعث می‌شود کل صفحه اسکرول نخورد
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans text-slate-900">
      {/* سایدبار ثابت */}
      <Sidebar />

      {/* بخش اصلی محتوا که اسکرول می‌خورد */}
      <main className="flex-1 flex flex-col h-full min-w-0 bg-slate-50/50 overflow-hidden">
        {/* هدر */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 lg:px-10 shrink-0 sticky top-0 z-20 shadow-sm">
          <div className="flex items-center gap-4 w-full md:w-auto">
            <Menu className="md:hidden text-slate-600 cursor-pointer hover:text-slate-900" />
            <div className="hidden md:flex items-center gap-2 bg-slate-100 px-3 py-2.5 rounded-xl w-96 border border-transparent focus-within:border-indigo-200 focus-within:bg-white transition-all">
              <Search size={18} className="text-slate-400" />
              <input
                type="text"
                placeholder="جستجو در دوره‌ها، تیم‌ها..."
                className="bg-transparent border-none outline-none text-sm w-full font-medium placeholder:text-slate-400"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-full transition">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="w-9 h-9 rounded-full bg-indigo-100 border border-indigo-200 overflow-hidden p-0.5 cursor-pointer">
              <img
                src="https://github.com/shadcn.png"
                alt="Avatar"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          </div>
        </header>

        {/* محتوای روتینگ که اسکرول می‌شود */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-10 scroll-smooth">
          {children}
        </div>
      </main>
    </div>
  );
}
