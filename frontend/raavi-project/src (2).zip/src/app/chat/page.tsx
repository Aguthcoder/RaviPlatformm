"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import {
  Send,
  Search,
  MoreVertical,
  Phone,
  Video,
  ArrowRight,
  Hash,
  Users,
} from "lucide-react";

// تعریف نوع داده‌ها
type Message = {
  id: number;
  text: string;
  time: string;
  isMe: boolean; // آیا پیام توسط کاربر فعلی ارسال شده؟
  senderName?: string; // نام فرستنده (برای پیام‌های دیگران)
};

type ChatRoom = {
  id: number;
  name: string;
  type: "group" | "private";
  avatarColor: string;
  lastMessage: string;
  unreadCount: number;
  messages: Message[];
};

export default function ChatPage() {
  // ۱. دیتای اولیه (شبیه سازی دیتابیس)
  const [chats, setChats] = useState<ChatRoom[]>([
    {
      id: 1,
      name: "رویداد استارتاپی تهران",
      type: "group",
      avatarColor: "bg-orange-500",
      lastMessage: "سلام بچه‌ها، کسی برای فردا آماده‌ست؟",
      unreadCount: 3,
      messages: [
        {
          id: 1,
          text: "سلام به همگی!",
          time: "10:00",
          isMe: false,
          senderName: "علی",
        },
        {
          id: 2,
          text: "سلام، بله من دارم اسلایدها رو چک می‌کنم.",
          time: "10:05",
          isMe: true,
        },
        {
          id: 3,
          text: "عالیه، مکان دقیق کجاست؟",
          time: "10:07",
          isMe: false,
          senderName: "مریم",
        },
      ],
    },
    {
      id: 2,
      name: "مشاوره روانشناسی",
      type: "private",
      avatarColor: "bg-blue-500",
      lastMessage: "ممنون از راهنمایی شما.",
      unreadCount: 0,
      messages: [
        { id: 1, text: "سلام، وقتتون بخیر.", time: "14:00", isMe: true },
        {
          id: 2,
          text: "سلام عزیزم، چطور میتونم کمکت کنم؟",
          time: "14:02",
          isMe: false,
          senderName: "دکتر راد",
        },
      ],
    },
    {
      id: 3,
      name: "گروه کوهنوردی",
      type: "group",
      avatarColor: "bg-green-600",
      lastMessage: "برنامه جمعه کنسل شد؟",
      unreadCount: 5,
      messages: [
        {
          id: 1,
          text: "هواشناسی اعلام بارندگی کرده.",
          time: "09:30",
          isMe: false,
          senderName: "سرپرست",
        },
      ],
    },
  ]);

  // ۲. استیت‌های رابط کاربری
  const [selectedChatId, setSelectedChatId] = useState<number>(1);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // پیدا کردن چت فعال
  const activeChat = chats.find((c) => c.id === selectedChatId);

  // اسکرول خودکار به پایین هنگام دریافت پیام جدید
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChat?.messages]);

  // ۳. تابع ارسال پیام
  const handleSendMessage = () => {
    if (!inputValue.trim() || !activeChat) return;

    const now = new Date();
    const timeString = `${now.getHours()}:${String(now.getMinutes()).padStart(2, "0")}`;

    const newMessage: Message = {
      id: Date.now(),
      text: inputValue.trim(),
      time: timeString,
      isMe: true,
    };

    // آپدیت کردن لیست چت‌ها با پیام جدید
    setChats((prevChats) =>
      prevChats.map((chat) => {
        if (chat.id === selectedChatId) {
          return {
            ...chat,
            messages: [...chat.messages, newMessage],
            lastMessage: newMessage.text, // آپدیت آخرین پیام در لیست
          };
        }
        return chat;
      }),
    );

    setInputValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSendMessage();
  };

  return (
    <div
      className="flex h-screen bg-slate-100 overflow-hidden font-sans"
      dir="rtl"
    >
      {/* -------------------- سایدبار (لیست چت‌ها) -------------------- */}
      <aside className="w-80 bg-[#111827] text-white flex flex-col border-l border-slate-700 shrink-0">
        {/* هدر سایدبار */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
              پیام‌رسان راوی
            </h2>
            {/* دکمه بازگشت به داشبورد */}
            <Link
              href="/dashboard"
              className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition text-slate-300 hover:text-white group"
              title="بازگشت به داشبورد"
            >
              <ArrowRight
                size={18}
                className="group-hover:-translate-x-1 transition-transform"
              />
            </Link>
          </div>

          {/* سرچ باکس */}
          <div className="relative">
            <Search
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500"
              size={16}
            />
            <input
              type="text"
              placeholder="جستجو..."
              className="w-full bg-slate-800 border-none rounded-xl py-2.5 pr-10 pl-4 text-sm text-slate-200 focus:ring-1 focus:ring-orange-500 placeholder:text-slate-600 transition-all"
            />
          </div>
        </div>

        {/* لیست چت‌ها */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
          {chats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 text-right group ${
                selectedChatId === chat.id
                  ? "bg-slate-800 border-r-4 border-orange-500 shadow-md"
                  : "hover:bg-slate-800/50 border-r-4 border-transparent"
              }`}
            >
              {/* آواتار */}
              <div
                className={`w-12 h-12 rounded-full ${chat.avatarColor} flex items-center justify-center text-white font-bold shrink-0 shadow-sm`}
              >
                {chat.type === "group" ? (
                  <Hash size={20} />
                ) : (
                  <span className="text-lg">{chat.name.charAt(0)}</span>
                )}
              </div>

              {/* متن لیست */}
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center mb-1">
                  <h3
                    className={`font-bold truncate text-sm ${selectedChatId === chat.id ? "text-white" : "text-slate-300 group-hover:text-white"}`}
                  >
                    {chat.name}
                  </h3>
                  {chat.unreadCount > 0 && (
                    <span className="bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 truncate group-hover:text-slate-400">
                  {chat.lastMessage}
                </p>
              </div>
            </button>
          ))}
        </div>
      </aside>

      {/* -------------------- محتوای چت اصلی -------------------- */}
      <main className="flex-1 flex flex-col bg-[#F3F4F6] relative">
        {activeChat ? (
          <>
            {/* هدر چت */}
            <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shadow-sm z-10">
              <div className="flex items-center gap-4">
                <div
                  className={`w-10 h-10 rounded-full ${activeChat.avatarColor} flex items-center justify-center text-white shadow-sm`}
                >
                  {activeChat.type === "group" ? (
                    <Hash size={18} />
                  ) : (
                    <span className="font-bold">
                      {activeChat.name.charAt(0)}
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">
                    {activeChat.name}
                  </h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                    {activeChat.type === "group" ? (
                      <>
                        <Users size={12} />
                        <span>۱۳ عضو • آنلاین</span>
                      </>
                    ) : (
                      "آخرین بازدید: به تازگی"
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 text-slate-400">
                <button className="hover:text-orange-500 transition">
                  <Phone size={20} />
                </button>
                <button className="hover:text-orange-500 transition">
                  <Video size={20} />
                </button>
                <button className="hover:text-slate-600 transition">
                  <MoreVertical size={20} />
                </button>
              </div>
            </header>

            {/* ناحیه پیام‌ها */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
              {/* بک‌گراند پترن (اختیاری برای زیبایی) */}
              <div
                className="absolute inset-0 opacity-[0.03] pointer-events-none"
                style={{
                  backgroundImage:
                    "radial-gradient(#64748b 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              ></div>

              {activeChat.messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex w-full ${msg.isMe ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] lg:max-w-[60%] px-4 py-3 rounded-2xl shadow-sm relative text-sm leading-6 ${
                      msg.isMe
                        ? "bg-orange-500 text-white rounded-br-none" // رنگ پیام‌های من (نارنجی)
                        : "bg-white text-slate-800 border border-slate-100 rounded-bl-none" // رنگ پیام‌های دیگران
                    }`}
                  >
                    {!msg.isMe && msg.senderName && (
                      <p className="text-[10px] font-bold text-orange-600 mb-1">
                        {msg.senderName}
                      </p>
                    )}
                    <p>{msg.text}</p>
                    <span
                      className={`text-[10px] block mt-1 text-left ${
                        msg.isMe ? "text-orange-100" : "text-slate-400"
                      }`}
                    >
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* ورودی متن */}
            <div className="p-4 bg-white border-t border-slate-200">
              <div className="max-w-4xl mx-auto relative flex items-center gap-3">
                <input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="پیام خود را بنویسید..."
                  className="flex-1 bg-slate-100 border-transparent focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-100 rounded-2xl px-5 py-4 text-sm transition-all outline-none"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim()}
                  className={`p-4 rounded-2xl transition-all shadow-md ${
                    inputValue.trim()
                      ? "bg-orange-500 text-white hover:bg-orange-600 active:scale-95 hover:shadow-orange-500/25"
                      : "bg-slate-200 text-slate-400 cursor-not-allowed"
                  }`}
                >
                  <Send
                    size={20}
                    className={inputValue.trim() ? "ml-0.5" : ""}
                  />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-slate-400">
            <p>لطفا یک گفتگو را انتخاب کنید</p>
          </div>
        )}
      </main>
    </div>
  );
}
