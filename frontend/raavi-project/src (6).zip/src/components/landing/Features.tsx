"use client";

import { BrainCircuit, HeartHandshake, Sparkles, Users } from "lucide-react";
import Reveal from "../Reveal";

const features = [
  {
    icon: <BrainCircuit className="w-8 h-8 md:w-10 md:h-10 text-white" />,
    title: "تحلیل هوش مصنوعی",
    desc: "الگوریتم‌های ما ویژگی‌های شخصیتی شما را با دقت تحلیل می‌کنند.",
    color: "bg-blue-500",
  },
  {
    icon: <Users className="w-8 h-8 md:w-10 md:h-10 text-white" />,
    title: "تطابق هوشمند",
    desc: "پیدا کردن افرادی که بیشترین هماهنگی ذهنی را با شما دارند.",
    color: "bg-orange-500",
  },
  {
    icon: <HeartHandshake className="w-8 h-8 md:w-10 md:h-10 text-white" />,
    title: "تعامل سازنده",
    desc: "ایجاد بستری برای گفتگوهای عمیق و ارتباطات پایدار.",
    color: "bg-green-500",
  },
  {
    icon: <Sparkles className="w-8 h-8 md:w-10 md:h-10 text-white" />,
    title: "تجربه متفاوت",
    desc: "رویدادهایی که خسته‌کننده نیستند و شما محور اصلی هستید.",
    color: "bg-purple-500",
  },
];

export default function Features() {
  return (
    <section className="py-20 md:py-32 bg-slate-50 relative overflow-hidden">
      {/* Background Shapes */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-100/50 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-100/50 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2" />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16 md:mb-20">
          <Reveal>
            <span className="text-orange-500 font-bold text-sm tracking-widest uppercase block mb-3">
              چطور کار می‌کند؟
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-slate-900 mb-6 leading-tight">
              مسیر هوشمند <br />
              <span className="text-orange-500">یافتن دوستان هم‌فکر</span>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-slate-500 text-lg">
              ما فرآیند آشنایی را از حالت تصادفی خارج کرده‌ایم و با علم و
              تکنولوژی آن را هدفمند ساخته‌ایم.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <Reveal
              key={index}
              delay={index * 0.1}
              className="bg-white p-6 md:p-8 rounded-[32px] shadow-xl shadow-slate-200/50 border border-slate-100 hover:-translate-y-2 transition-transform duration-300 group"
            >
              <div
                className={`${feature.color} w-16 h-16 md:w-20 md:h-20 rounded-2xl md:rounded-[24px] flex items-center justify-center mb-6 shadow-lg rotate-3 group-hover:rotate-6 transition-transform`}
              >
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-slate-500 text-sm leading-relaxed">
                {feature.desc}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
