"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import Reveal from "../Reveal";

const testimonials = [
  {
    text: "تجربه‌ای فوق‌العاده بود. برای اولین بار در جمعی قرار گرفتم که واقعاً حس می‌کردم حرف هم را می‌فهمیم. هوش مصنوعی دقیقاً کسانی را پیشنهاد داده بود که با روحیات من سازگار بودند.",
    author: "سارا محمدی",
    role: "طراح گرافیک",
    image:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
  },
  {
    text: "همیشه فکر می‌کردم پیدا کردن دوستان جدید در این سن سخت است، اما راوی این کار را مثل آب خوردن کرد. کیفیت رویداد و سطح افراد شرکت‌کننده بسیار بالا بود.",
    author: "علی رستمی",
    role: "برنامه‌نویس ارشد",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
  },
  {
    text: "من آدم درون‌گرایی هستم و معمولاً در جمع‌ها معذب می‌شوم، اما چون افراد گروه شبیه خودم بودند، خیلی راحت توانستم ارتباط برقرار کنم. ممنون از تیم راوی.",
    author: "مریم کریمی",
    role: "نویسنده",
    image:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
  },
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex(
      (prev) => (prev - 1 + testimonials.length) % testimonials.length,
    );
  };

  return (
    <section className="py-20 bg-white relative">
      <div className="container mx-auto px-4 md:px-12 relative">
        <Reveal className="text-center mb-16">
          <span className="text-orange-500 font-bold text-sm tracking-widest uppercase">
            نظرات کاربران
          </span>
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 mt-3">
            داستان‌های <span className="text-orange-500">راوی</span>
          </h2>
        </Reveal>

        <div className="relative max-w-4xl mx-auto">
          {/* Navigation Buttons Outside */}
          <button
            onClick={next}
            className="absolute -left-4 md:-left-16 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white border border-slate-200 text-slate-600 rounded-full flex items-center justify-center hover:bg-orange-500 hover:text-white hover:border-orange-500 transition shadow-lg"
          >
            <ChevronLeft size={24} />
          </button>

          <button
            onClick={prev}
            className="absolute -right-4 md:-right-16 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white border border-slate-200 text-slate-600 rounded-full flex items-center justify-center hover:bg-orange-500 hover:text-white hover:border-orange-500 transition shadow-lg"
          >
            <ChevronRight size={24} />
          </button>

          <div className="overflow-hidden rounded-[40px] shadow-2xl shadow-slate-200/50 bg-white border border-slate-100 min-h-[300px] flex items-center">
            <div
              className="flex transition-transform duration-500 ease-in-out w-full"
              style={{ transform: `translateX(${currentIndex * 100}%)` }} // LTR/RTL logic: for RTL might need negative or dir adjustment. Assuming standard flex direction.
            >
              {testimonials.map((item, idx) => (
                <div
                  key={idx}
                  className="w-full flex-shrink-0 p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 md:gap-12"
                >
                  {/* Image */}
                  <div className="shrink-0 relative">
                    <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-orange-100 shadow-inner">
                      <img
                        src={item.image}
                        alt={item.author}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 bg-orange-500 text-white p-2 rounded-full">
                      <Quote size={16} fill="currentColor" />
                    </div>
                  </div>

                  {/* Text */}
                  <div className="text-center md:text-right flex-1">
                    <p className="text-slate-600 text-base md:text-xl font-medium leading-loose mb-6 italic">
                      "{item.text}"
                    </p>
                    <div>
                      <h4 className="font-bold text-slate-900 text-lg">
                        {item.author}
                      </h4>
                      <span className="text-orange-500 text-sm font-bold">
                        {item.role}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  i === currentIndex ? "bg-orange-500 w-8" : "bg-slate-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
