"use client";

import { useEffect, useState } from "react";
import Preloader from "./Preloader";
import { usePathname } from "next/navigation";

export default function ClientShell({
  children,
}: {
  children: React.ReactNode;
}) {
  const [loading, setLoading] = useState(true);
  const pathname = usePathname();

  useEffect(() => {
    // هر بار که مسیر تغییر کند، لودینگ نمایش داده شود
    setLoading(true);
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000); // زمان نمایش لودر (2 ثانیه)

    return () => clearTimeout(timer);
  }, [pathname]);

  return (
    <>
      {loading && <Preloader />}
      <div className={loading ? "hidden" : "block"}>{children}</div>
    </>
  );
}
