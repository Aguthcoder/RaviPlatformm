"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  UserCircle,
  Calendar,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Compass,
} from "lucide-react";
import { useState } from "react";

const sidebarItems = [
  { icon: LayoutDashboard, label: "داشبورد", href: "/dashboard" },
  { icon: UserCircle, label: "پروفایل من", href: "/dashboard/profile" },
  { icon: Compass, label: "کاوش رویدادها", href: "/dashboard/explore" }, // آدرس جدید برای کاوش
  { icon: Calendar, label: "رویدادهای من", href: "/dashboard/my-events" },
  { icon: MessageSquare, label: "چت گروهی", href: "/chat" },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans flex">
      {/* Mobile Sidebar Overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:sticky top-0 right-0 h-screen w-72 bg-white border-l border-slate-200 flex flex-col z-50 transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen
            ? "translate-x-0"
            : "translate-x-full md:translate-x-0"
        }`}
      >
        <div className="p-6 md:p-8 border-b border-slate-100 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-orange-200">
              R
            </div>
            <span className="font-black text-2xl text-slate-900">راوی</span>
          </Link>
          <button
            className="md:hidden text-slate-500"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={24} />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {sidebarItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all font-bold text-sm ${
                  isActive
                    ? "bg-orange-50 text-orange-600 shadow-sm"
                    : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <item.icon
                  size={20}
                  className={isActive ? "text-orange-500" : "text-slate-400"}
                />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <Link
            href="/"
            className="flex items-center gap-3 px-4 py-3.5 rounded-xl text-red-500 hover:bg-red-50 transition-colors font-bold text-sm"
          >
            <LogOut size={20} />
            خروج از حساب
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Mobile Header */}
        <div className="md:hidden h-16 bg-white border-b border-slate-200 flex items-center px-4 justify-between sticky top-0 z-30">
          <div className="font-bold text-slate-900">داشبورد</div>
          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 bg-slate-50 rounded-lg text-slate-600"
          >
            <Menu size={24} />
          </button>
        </div>

        <div className="p-4 md:p-8 pb-24">{children}</div>
      </main>
    </div>
  );
}
