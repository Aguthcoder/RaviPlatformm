"use client";

import { useAppContext } from "@/context/AppContext";
import { EVENTS_DATA } from "@/lib/events-data";
import {
  Bell,
  Calendar,
  ChevronLeft,
  Clock,
  MapPin,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import Link from "next/link";

export default function DashboardPage() {
  const { state } = useAppContext();
  const user = state.user || { name: "کاربر", role: "عضو جدید" };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 mb-2">
            سلام {user.name}، خوش اومدی! 👋
          </h1>
          <p className="text-slate-500 text-sm md:text-base">
            امروز فرصت‌های جدیدی برای آشنایی منتظر توست.
          </p>
        </div>
        <div className="flex gap-3">
          <button className="w-10 h-10 md:w-12 md:h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-600 border border-slate-100 hover:bg-slate-100 transition relative">
            <Bell size={20} />
            <span className="absolute top-2 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: "رویدادهای من",
            value: "۳",
            icon: Calendar,
            color: "text-blue-500 bg-blue-50",
          },
          {
            label: "ارتباطات جدید",
            value: "۱۲",
            icon: TrendingUp,
            color: "text-green-500 bg-green-50",
          },
          {
            label: "امتیاز فعالیت",
            value: "۸۵۰",
            icon: Sparkles,
            color: "text-orange-500 bg-orange-50",
          },
          {
            label: "روزهای عضویت",
            value: "۴۵",
            icon: Clock,
            color: "text-purple-500 bg-purple-50",
          },
        ].map((stat, i) => (
          <div
            key={i}
            className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center gap-2"
          >
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${stat.color} mb-1`}
            >
              <stat.icon size={20} />
            </div>
            <div className="text-2xl font-black text-slate-900">
              {stat.value}
            </div>
            <div className="text-xs text-slate-500 font-bold">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Suggested Events */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="text-orange-500" size={20} />
            پیشنهادهای ویژه برای شما
          </h2>
          <Link
            href="/dashboard/explore"
            className="text-sm font-bold text-orange-500 flex items-center hover:gap-2 transition-all"
          >
            مشاهده همه <ChevronLeft size={16} />
          </Link>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {EVENTS_DATA.slice(0, 2).map((event) => (
            <div
              key={event.id}
              className="group bg-white rounded-[24px] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 overflow-hidden flex flex-col"
            >
              <div className="h-48 overflow-hidden relative">
                <img
                  src={event.image} // Dynamic Image here
                  alt={event.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-slate-900 shadow-sm">
                  {event.category}
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                  <span className="flex items-center gap-1">
                    <Calendar size={14} /> {event.date}
                  </span>
                  <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                  <span className="flex items-center gap-1">
                    <MapPin size={14} /> {event.city}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 leading-tight">
                  {event.title}
                </h3>
                <div className="mt-auto pt-4 flex items-center justify-between">
                  <div className="text-orange-600 font-black">
                    {event.price === 0
                      ? "رایگان"
                      : `${event.price.toLocaleString("fa-IR")} تومان`}
                  </div>
                  <Link href={`/events/${event.id}/booking`}>
                    <button className="bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-slate-800 transition">
                      مشاهده جزئیات
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
