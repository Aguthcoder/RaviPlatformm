"use client";

import { EVENTS_DATA } from "@/lib/events-data";
import { Calendar, MapPin, Search } from "lucide-react";
import Link from "next/link";

export default function ExploreEventsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-black text-slate-900">کاوش رویدادها</h1>
        <div className="relative w-full md:w-80">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
            size={20}
          />
          <input
            type="text"
            placeholder="جستجوی رویداد..."
            className="w-full bg-white border border-slate-200 rounded-xl py-3 pr-10 pl-4 text-sm focus:outline-none focus:border-orange-500 transition"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {EVENTS_DATA.map((event) => (
          <div
            key={event.id}
            className="bg-white rounded-[24px] overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col"
          >
            <div className="h-48 relative">
              <img
                src={event.image}
                alt={event.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-slate-900">
                {event.category}
              </div>
            </div>
            <div className="p-5 flex-1 flex flex-col">
              <h3 className="font-bold text-slate-900 text-lg mb-2">
                {event.title}
              </h3>
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Calendar size={14} />
                  {event.date} | {event.time}
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <MapPin size={14} />
                  {event.city}
                </div>
              </div>
              <div className="mt-auto flex items-center justify-between pt-4 border-t border-slate-50">
                <span className="font-black text-orange-600">
                  {event.price === 0
                    ? "رایگان"
                    : event.price.toLocaleString("fa-IR")}
                </span>
                <Link href={`/events/${event.id}/booking`}>
                  <button className="bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold">
                    مشاهده و رزرو
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
