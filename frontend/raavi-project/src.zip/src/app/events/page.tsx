"use client";

import { useAppContext } from "@/context/AppContext";
import Link from "next/link";
import { MapPin, Calendar, ArrowRight } from "lucide-react";

// داده‌های نمونه (استاتیک)
const EVENTS = [
  {
    id: 1,
    title: "میت‌آپ برنامه‌نویسان ارشد",
    city: "تهران",
    date: "1402/12/10",
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800",
  },
  {
    id: 2,
    title: "کوهنوردی گروهی دراک",
    city: "شیراز",
    date: "1402/12/15",
    image: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=800",
  },
  {
    id: 3,
    title: "کافه کتاب و نقد ادبی",
    city: "تهران",
    date: "1402/12/20",
    image: "https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?w=800",
  },
  {
    id: 4,
    title: "ورکشاپ هوش مصنوعی",
    city: "مشهد",
    date: "1402/12/25",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800",
  },
];

export default function EventsPage() {
  // استخراج صحیح استیت از کانتکست
  const { state } = useAppContext();
  const { userCity } = state;

  // فیلتر کردن رویدادها: اگر شهر ست شده باشد فیلتر کن، وگرنه همه را نشان بده
  const filteredEvents = userCity
    ? EVENTS.filter((e) => e.city === userCity)
    : EVENTS;

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-6 font-sans">
      <div className="max-w-6xl mx-auto">
        {/* هدر و بنر تغییر شهر */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-4">
          <div>
            <h1 className="text-3xl font-black text-slate-900">
              رویدادهای پیش‌رو
            </h1>
            <p className="text-slate-500 mt-2">
              {userCity
                ? `نمایش رویدادهای شهر اختصاصی شما: ${userCity}`
                : "نمایش تمام رویدادها (برای فیلتر دقیق‌تر پروفایل خود را تکمیل کنید)"}
            </p>
          </div>

          {userCity ? (
            <Link
              href="/dashboard/complete-profile"
              className="text-sm text-blue-600 hover:underline bg-blue-50 px-4 py-2 rounded-lg"
            >
              تغییر شهر سکونت ({userCity})
            </Link>
          ) : (
            <Link
              href="/dashboard/complete-profile"
              className="px-6 py-2 bg-slate-900 text-white rounded-xl text-sm font-bold"
            >
              انتخاب شهر
            </Link>
          )}
        </div>

        {/* لیست کارت‌ها */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.length > 0 ? (
            filteredEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300 border border-slate-100 flex flex-col"
              >
                {/* تصویر کارت */}
                <div className="h-48 bg-slate-200 relative">
                  <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-4 right-4 bg-white/90 backdrop-blur text-slate-900 text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                    {event.city}
                  </span>
                </div>

                <div className="p-6 flex flex-col flex-1">
                  <h3 className="text-xl font-bold text-slate-800 mb-2">
                    {event.title}
                  </h3>

                  <div className="flex items-center text-slate-500 text-sm mb-6 gap-2 mt-auto pt-4">
                    <Calendar size={16} />
                    <span>تاریخ: {event.date}</span>
                  </div>

                  <Link
                    href={`/event/${event.id}/booking`}
                    className="flex items-center justify-center gap-2 w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-700 transition"
                  >
                    مشاهده و رزرو <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
              <MapPin size={48} className="text-slate-300 mb-4" />
              <p className="text-slate-500 text-lg">
                هنوز رویدادی برای شهر "{userCity}" تعریف نشده است.
              </p>
              <button
                onClick={() => window.location.reload()} // یا ریست کردن فیلتر
                className="mt-4 text-slate-900 font-bold hover:underline"
              >
                بارگذاری مجدد
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
