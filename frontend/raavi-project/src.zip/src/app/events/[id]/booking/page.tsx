// src/app/events/[id]/booking/page.tsx
"use client";

import { useAppContext } from "@/context/AppContext";
import { useRouter, useParams } from "next/navigation";
import {
  ArrowLeft,
  Check,
  AlertCircle,
  Calendar,
  Clock,
  MapPin,
} from "lucide-react";
import Link from "next/link";
import CountdownTimer from "@/components/CountdownTimer";
import { useMemo, useState } from "react";

export default function BookingPage() {
  const { state } = useAppContext();
  const router = useRouter();
  const params = useParams();
  const id = (params?.id as string) || "next";

  const [showError, setShowError] = useState(false);

  const isTestTaken = state.isTestTaken;
  const city = state.userCity || "تهران";

  const price = useMemo(() => 490000, []);

  const handleFinalReserve = () => {
    if (!isTestTaken) {
      setShowError(true);
      return;
    }
    router.push(`/checkout?eventId=${id}`);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 px-6 py-10">
      <div className="max-w-5xl mx-auto bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-gradient-to-r from-white to-slate-50 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black text-slate-900">
              رزرو نهایی رویداد
            </h1>
            <p className="text-slate-500 mt-1">ایونت: {id}</p>
          </div>
          <Link
            href="/events"
            className="inline-flex items-center gap-2 text-slate-400 text-sm hover:text-slate-600 transition"
          >
            <ArrowLeft size={16} /> بازگشت به رویدادها
          </Link>
        </div>

        {/* Body */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left - Info */}
          <div className="space-y-6">
            {/* Timer */}
            <div className="rounded-2xl border border-slate-200 p-4 bg-slate-50">
              <CountdownTimer />
            </div>

            {/* Event Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 p-4 rounded-2xl border border-slate-200 bg-white">
                <Calendar className="text-orange-500" />
                <div>
                  <div className="text-xs text-slate-500">تاریخ</div>
                  <div className="font-bold text-slate-900">جمعه 12 اسفند</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 rounded-2xl border border-slate-200 bg-white">
                <Clock className="text-orange-500" />
                <div>
                  <div className="text-xs text-slate-500">ساعت</div>
                  <div className="font-bold text-slate-900">
                    18:00 الی 21:00
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 rounded-2xl border border-slate-200 bg-white">
                <MapPin className="text-orange-500" />
                <div>
                  <div className="text-xs text-slate-500">محل برگزاری</div>
                  <div className="font-bold text-slate-900">{city}</div>
                </div>
              </div>
            </div>

            {/* Status / Requirements */}
            <div
              className={`flex items-start gap-3 p-4 border rounded-2xl transition-all duration-300 ${
                showError
                  ? "bg-red-50 border-red-200 text-red-800 shake-animation"
                  : !isTestTaken
                    ? "bg-orange-50 border-orange-100 text-orange-800"
                    : "bg-green-50 border-green-100 text-green-800"
              }`}
            >
              <AlertCircle size={20} className="shrink-0 mt-0.5" />
              <div>
                {!isTestTaken ? (
                  <>
                    <p className="font-bold mb-1">تست روانشناسی الزامی است</p>
                    <p className="text-sm opacity-90">
                      برای شرکت در این رویداد، ابتدا باید{" "}
                      <Link href="/test" className="underline font-bold">
                        تست شخصیت‌شناسی
                      </Link>{" "}
                      را تکمیل کنید.
                    </p>
                  </>
                ) : (
                  <p className="font-bold text-sm">
                    مدارک روانشناسی شما تایید شده است.
                  </p>
                )}
              </div>
            </div>

            {/* Guarantee */}
            <div className="flex items-center gap-4 p-4 border border-slate-100 rounded-2xl bg-white">
              <div className="bg-green-50 p-2 rounded-lg">
                <Check size={20} className="text-green-600" />
              </div>
              <div>
                <p className="font-bold text-slate-800">تضمین بازگشت وجه</p>
                <p className="text-xs text-slate-500">
                  تا ۲۴ ساعت قبل از رویداد
                </p>
              </div>
            </div>

            {/* Price & CTA */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-4">
              <div className="text-slate-900">
                <div className="text-sm text-slate-500">هزینه شرکت</div>
                <div className="text-2xl font-black">
                  {price.toLocaleString("fa-IR")} تومان
                </div>
              </div>
              {!isTestTaken ? (
                <Link
                  href="/test"
                  className="px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white rounded-2xl font-bold transition shadow-lg shadow-orange-200 w-full md:w-auto text-center"
                >
                  شروع تست (الزامی)
                </Link>
              ) : (
                <button
                  onClick={handleFinalReserve}
                  className="px-8 py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold transition shadow-xl hover:shadow-2xl active:scale-95 w-full md:w-auto"
                >
                  رزرو نهایی
                </button>
              )}
            </div>
          </div>

          {/* Right - Image */}
          <div className="relative h-[480px] bg-slate-100 rounded-3xl overflow-hidden shadow-xl">
            <img
              src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1000&q=80&auto=format&fit=crop"
              className="w-full h-full object-cover"
              alt="Event"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-8">
              <div className="text-white">
                <p className="font-bold text-lg mb-1">میت‌آپ تخصصی</p>
                <p className="text-sm opacity-80">
                  {city} • ظرفیت محدود • پذیرایی رایگان
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
