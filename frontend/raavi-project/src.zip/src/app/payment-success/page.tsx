"use client";

import {
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Send,
  MessageSquare,
  Users,
} from "lucide-react";

export default function PaymentSuccessPage() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 font-sans">
      <div className="max-w-4xl w-full text-center">
        {/* آیکون موفقیت */}
        <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="text-green-600 w-12 h-12" />
        </div>

        <h1 className="text-3xl font-bold text-slate-900 mb-2">
          پرداخت با موفقیت انجام شد!
        </h1>
        <p className="text-slate-500 mb-10 text-lg">
          ممنون از خرید شما. حالا می‌توانید وارد گروه شوید.
        </p>

        {/* کارت‌های انتخاب */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-right">
          {/* گزینه ۱: کانال تلگرام */}
          <a
            href="https://t.me/your_channel"
            target="_blank"
            rel="noreferrer"
            className="group"
          >
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 hover:border-blue-500 hover:shadow-xl transition-all duration-300 h-full flex flex-col justify-between">
              <div>
                <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500 mb-6 group-hover:scale-110 transition-transform">
                  <Send size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">
                  ورود به کانال کلی پلتفرم
                </h3>
                <p className="text-slate-500 leading-relaxed">
                  برای دریافت اطلاعیه‌های عمومی و خبرهای مهم به کانال تلگرام
                  رسمی ما بپیوندید.
                </p>
              </div>
              <div className="mt-6 flex items-center justify-end text-blue-600 font-bold group-hover:translate-x-[-5px] transition-transform">
                ورود به کانال <ArrowLeft className="mr-2" size={20} />
              </div>
            </div>
          </a>

          {/* گزینه ۲: چت گروهی سایت */}
          <div
            onClick={() => (window.location.href = "/chat")}
            className="group cursor-pointer"
          >
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 hover:border-orange-500 hover:shadow-xl transition-all duration-300 h-full flex flex-col justify-between">
              <div>
                <div className="w-14 h-14 bg-orange-50 rounded-xl flex items-center justify-center text-orange-500 mb-6 group-hover:scale-110 transition-transform">
                  <Users size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">
                  چت گروهی ایونت
                </h3>
                <p className="text-slate-500 leading-relaxed">
                  ورود مستقیم به اتاق گفتگوی مربوط به این رویداد برای ارتباط با
                  هم‌تیمی‌ها و مدرس.
                </p>
              </div>
              <div className="mt-6 flex items-center justify-end text-orange-600 font-bold group-hover:translate-x-[-5px] transition-transform">
                ورود به چت <ArrowLeft className="mr-2" size={20} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
