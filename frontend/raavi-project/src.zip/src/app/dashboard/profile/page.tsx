"use client";

import {
  User,
  CheckCircle,
  Eye,
  MessageCircle,
  MoreHorizontal,
  AlertCircle,
} from "lucide-react";
import { useAppContext } from "@/context/AppContext";

export default function UserProfile() {
  // ۱. اصلاح نحوه دسترسی به کانتکست
  const { state } = useAppContext();
  const { userCity, isTestTaken } = state; // دریافت شهر و وضعیت تست از استیت

  // ۲. تعریف داده‌های نمایشی کاربر (چون هنوز در کانتکست ذخیره نشده‌اند)
  const userData = {
    name: "سارا جهانگیری", // نام پیش‌فرض یا نمایشی
    avatar: "https://github.com/shadcn.png",
    job: "توسعه‌دهنده وب",
  };

  return (
    <div className="p-6 md:p-10 space-y-8 bg-slate-50 min-h-screen font-sans">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-black text-slate-900">پروفایل کاربری</h1>
          <p className="text-slate-500 text-sm mt-1">
            مدیریت اطلاعات و مشاهده عملکرد
          </p>
        </div>
        <button className="mt-4 md:mt-0 px-5 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 font-medium text-sm transition">
          ویرایش اطلاعات
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card 1 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center text-red-500">
            <MessageCircle size={24} />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase">
              پیام‌های نخوانده
            </p>
            <h3 className="text-2xl font-black text-slate-900 mt-1">۱۲</h3>
          </div>
        </div>
        {/* Card 2 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-500">
            <CheckCircle size={24} />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase">
              تطابق‌های موفق
            </p>
            <h3 className="text-2xl font-black text-slate-900 mt-1">۸۵٪</h3>
          </div>
        </div>
        {/* Card 3 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-blue-500">
            <Eye size={24} />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase">
              بازدید پروفایل
            </p>
            <h3 className="text-2xl font-black text-slate-900 mt-1">۱,۲۰۴</h3>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Column: User Info Card */}
        <div className="w-full lg:w-1/3">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col items-center text-center sticky top-10">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4 ring-2 ring-slate-100">
              <img
                src={userData.avatar}
                className="w-full h-full object-cover"
                alt="User Avatar"
              />
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              {userData.name}
            </h2>
            <p className="text-slate-500 text-sm mb-6">
              {userData.job} • {userCity || "شهر نامشخص"}
            </p>

            <div className="w-full border-t border-slate-100 pt-4 flex justify-between items-center text-sm">
              <span className="text-slate-500">وضعیت تست:</span>
              {isTestTaken ? (
                <span className="text-green-600 font-bold flex items-center gap-1">
                  <CheckCircle size={14} /> انجام شده
                </span>
              ) : (
                <span className="text-orange-600 font-bold flex items-center gap-1">
                  <AlertCircle size={14} /> ناقص
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: List (Successful Events) */}
        <div className="w-full lg:w-2/3">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg text-slate-800">
                رویدادهای موفق اخیر
              </h3>
              <button className="text-slate-400 hover:text-slate-600">
                <MoreHorizontal />
              </button>
            </div>

            <div className="space-y-4">
              {[1, 2, 3].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-4 p-4 rounded-xl hover:bg-slate-50 transition border border-transparent hover:border-slate-100 cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-lg bg-slate-200 overflow-hidden shrink-0">
                    <img
                      src={`https://picsum.photos/200?random=${item}`}
                      className="w-full h-full object-cover"
                      alt="Event"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-slate-800 text-sm truncate">
                      کارگاه تیم‌سازی در {userCity || "تهران"}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      ۱۴۰۴/۱۰/۲۰ • حضوری
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full shrink-0">
                    تکمیل شده
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
