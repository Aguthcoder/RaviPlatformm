import Link from "next/link";
import {
  Home,
  Users,
  BookOpen,
  Settings,
  LogOut,
  Menu,
  Bell,
  Search,
} from "lucide-react";
import { ReactNode } from "react";

const menuItems = [
  { icon: Home, label: "داشبورد", href: "/dashboard" },
  { icon: Users, label: "گروه‌ها و تیم‌ها", href: "/dashboard/groups" },
  { icon: BookOpen, label: "دوره‌ها و آموزش", href: "/dashboard/courses" },
  { icon: Settings, label: "تنظیمات", href: "/dashboard/settings" },
];

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* سایدبار (سمت راست به دلیل RTL) */}
      <aside className="w-72 bg-dark-900 text-white flex flex-col hidden md:flex shadow-2xl z-20">
        <div className="p-6 border-b border-dark-800">
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <span className="w-3 h-3 bg-primary-500 rounded-full"></span>
            MyPlatform
          </h1>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-4 px-4 py-3 text-slate-300 hover:bg-slate-800 hover:text-white rounded-xl transition-all duration-200 group"
            >
              <item.icon
                size={20}
                className="group-hover:text-primary-500 transition-colors"
              />
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-dark-800 bg-dark-800/50">
          <div className="flex items-center gap-3 p-2 hover:bg-dark-800 rounded-xl cursor-pointer transition">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-primary-500 to-yellow-500 flex items-center justify-center font-bold text-white text-lg shadow-lg">
              S
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate">سارا جهانگیری</p>
              <p className="text-xs text-primary-400">کاربر ممتاز (VIP)</p>
            </div>
            <LogOut size={18} className="text-slate-400 hover:text-white" />
          </div>
        </div>
      </aside>

      {/* محتوای اصلی */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50/50">
        {/* هدر موبایل/دسکتاپ */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 lg:px-10 sticky top-0 z-10">
          <div className="flex items-center gap-4 w-full md:w-auto">
            <Menu className="md:hidden text-slate-600 cursor-pointer" />
            <div className="hidden md:flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-lg w-96">
              <Search size={18} className="text-slate-400" />
              <input
                type="text"
                placeholder="جستجو در دوره‌ها، تیم‌ها..."
                className="bg-transparent border-none outline-none text-sm w-full"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-full">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
              <img
                src="/avatar-placeholder.png"
                alt="Avatar"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </header>

        {/* محتوای رخداد */}
        <div className="flex-1 overflow-auto p-6 lg:p-10">{children}</div>
      </main>
    </div>
  );
}
