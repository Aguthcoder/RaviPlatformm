// src/app/dashboard/complete-profile/page.tsx
"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Input } from "@/components/ui/input";
import { useAppContext } from "@/context/AppContext";

export default function CompleteProfilePage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const search = useSearchParams();
  const redirect = search.get("redirect") || "/events/next/booking";
  const { dispatch } = useAppContext();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const city = (formData.get("city") as string) || "تهران";

    // شبیه‌سازی ذخیره
    await new Promise((r) => setTimeout(r, 600));

    dispatch({ type: "SET_CITY", payload: city });
    dispatch({ type: "COMPLETE_PROFILE" });

    setLoading(false);

    // پس از ذخیره پروفایل، کاربر می‌تواند تست را شروع کند
    router.push(`/test?redirect=${encodeURIComponent(redirect)}`);
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      <div className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-black mb-8">تکمیل پروفایل کاربری</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">
              نام و نام خانوادگی
            </label>
            <Input name="fullname" placeholder="مثلاً: آرین رضایی" />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">
              شهر سکونت
            </label>
            <Input name="city" placeholder="مثلاً: تهران" />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">
              شغل / تخصص
            </label>
            <Input name="job" placeholder="مثلاً: برنامه‌نویس ارشد" />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">
              علایق
            </label>
            <Input
              name="interests"
              placeholder="مثلاً: فیلم، موسیقی، بازی‌های فکری"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-slate-900 text-white rounded-xl py-3 font-bold hover:bg-slate-800 transition btn-3d disabled:opacity-60"
          >
            {loading ? "در حال ذخیره..." : "ثبت و شروع تست روانشناسی"}
          </button>
        </form>
      </div>
    </div>
  );
}
