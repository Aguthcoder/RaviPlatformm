// src/app/chat/page.tsx
"use client";

import { useSearchParams } from "next/navigation";
import { useState } from "react";

type Message = { id: number; user: string; text: string; time: string };

export default function ChatPage() {
  const search = useSearchParams();
  const eventId = search.get("eventId") || "next";

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      user: "سیستم",
      text: `به گروه ایونت ${eventId} خوش آمدید!`,
      time: "18:00",
    },
    {
      id: 2,
      user: "آرین",
      text: "سلام به همه! مشتاق دیدارتون در رویداد.",
      time: "18:02",
    },
    { id: 3, user: "نیلوفر", text: "کسی از رشت هست؟", time: "18:05" },
  ]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    const now = new Date();
    setMessages((prev) => [
      ...prev,
      {
        id: prev.length + 1,
        user: "من",
        text: input.trim(),
        time: `${now.getHours()}:${String(now.getMinutes()).padStart(2, "0")}`,
      },
    ]);
    setInput("");
  };

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-10">
      <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h1 className="text-xl font-black">گفتگو گروهی ایونت: {eventId}</h1>
          <p className="text-slate-500 text-sm mt-1">
            قوانین: احترام، عدم ارسال اسپم، رعایت حریم خصوصی
          </p>
        </div>
        <div className="p-6 h-[60vh] overflow-y-auto space-y-3">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${m.user === "من" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm ${
                  m.user === "من"
                    ? "bg-slate-900 text-white rounded-br-none"
                    : "bg-slate-100 text-slate-900 rounded-bl-none"
                }`}
              >
                <div className="text-xs opacity-70 mb-1">
                  {m.user} • {m.time}
                </div>
                <div>{m.text}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-slate-100 flex items-center gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="پیام خود را بنویسید..."
            className="flex-1 border border-slate-200 rounded-xl px-4 py-3"
          />
          <button
            onClick={send}
            className="bg-orange-500 text-white rounded-xl px-5 py-3 font-bold hover:bg-orange-600 transition"
          >
            ارسال
          </button>
        </div>
      </div>
    </div>
  );
}
