"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle2,
  Brain,
  BarChart3,
  Users,
  Calendar,
  ChevronDown,
  Menu,
  X,
  Zap,
  Check,
  Star,
} from "lucide-react";
import { useAppContext } from "@/context/AppContext";
import CountdownTimer from "@/components/CountdownTimer";
import Reveal from "@/components/Reveal";
import TestimonialsCarousel from "@/components/TestimonialsCarousel";

const faqItems = [
  {
    question: "چطور الگوریتم هوش مصنوعی راوی تطابق ایجاد می‌کند؟",
    answer:
      "ما ابتدا تیپ شخصیتی، علایق و سبک زندگی شما را با یک تست علمی شناسایی می‌کنیم. سپس الگوریتم با تحلیل داده‌های مشابهات افراد دیگر، بهترین هم‌نشین‌ها را پیشنهاد می‌دهد.",
  },
  {
    question: "آیا رویدادهای راوی آنلاین هم برگزار می‌شوند؟",
    answer:
      "بله، علاوه بر رویدادهای حضوری، جلسات آنلاین گروهی نیز داریم تا بتوانید در هر شرایطی با افراد جدید آشنا شوید.",
  },
  {
    question: "چطور از امنیت و حریم خصوصی کاربران محافظت می‌کنید؟",
    answer:
      "همه داده‌ها با استانداردهای امنیتی بالا نگهداری می‌شوند و هیچ اطلاعاتی بدون اجازه شما به اشتراک گذاشته نمی‌شود. ما روی ایجاد فضایی امن و حرفه‌ای تمرکز داریم.",
  },
  {
    question: "اگر از پیشنهادها راضی نبودم چه می‌شود؟",
    answer:
      "تیم پشتیبانی راوی در کنار شماست تا با بازنگری در پروفایل و دادن بازخورد به الگوریتم، نتایج بهتری ارائه شود.",
  },
];

export default function LandingPage() {
  const { state } = useAppContext();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const ctaHref = useMemo(() => {
    if (!state.isLoggedIn) return "/test";
    if (!state.isProfileComplete || !state.isTestTaken) {
      return "/dashboard/complete-profile";
    }
    return "/events/next/booking";
  }, [state.isLoggedIn, state.isProfileComplete, state.isTestTaken]);

  const handleFaqToggle = (index: number) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 overflow-x-hidden">
      {/* ================= HEADER ================= */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md z-50 border-b border-slate-100 h-20 flex items-center">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-orange-200">
              <Zap size={24} fill="currentColor" />
            </div>
            <span className="text-2xl font-black text-slate-800 tracking-tight">
              راوی
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-slate-500 font-medium">
            <Link href="/" className="text-orange-600 font-bold">
              خانه
            </Link>
            <Link href="#" className="hover:text-slate-900 transition">
              درباره ما
            </Link>
            <Link href="/events" className="hover:text-slate-900 transition">
              رویدادها
            </Link>
            <Link href="#" className="hover:text-slate-900 transition">
              تماس با ما
            </Link>
          </nav>

          <div className="hidden md:flex items-center gap-4">
            {state.isLoggedIn ? (
              <Link href="/dashboard">
                <button className="bg-slate-900 text-white px-6 py-2.5 rounded-full font-bold hover:bg-slate-800 transition shadow-lg shadow-slate-200">
                  ورود به داشبورد
                </button>
              </Link>
            ) : (
              <>
                <Link
                  href="/login"
                  className="text-slate-600 font-bold hover:text-slate-900"
                >
                  ورود
                </Link>
                <Link href="/test">
                  <button className="bg-orange-500 text-white px-6 py-2.5 rounded-full font-bold hover:bg-orange-600 transition shadow-lg shadow-orange-200">
                    ثبت نام رایگان
                  </button>
                </Link>
              </>
            )}
          </div>

          <button
            className="md:hidden p-2 text-slate-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="absolute top-20 left-0 right-0 bg-white border-b border-slate-100 p-6 flex flex-col gap-4 shadow-xl md:hidden">
            <Link href="/" className="text-orange-600 font-bold">
              خانه
            </Link>
            <Link href="/events">رویدادها</Link>
            <Link href="/login">ورود</Link>
            <Link
              href="/test"
              className="bg-orange-500 text-white text-center py-3 rounded-xl font-bold"
            >
              شروع کنید
            </Link>
          </div>
        )}
      </header>

      {/* ================= HERO ================= */}
      <Reveal
        as="section"
        direction="right"
        className="pt-32 pb-20 px-6 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-50 rounded-full blur-[100px] -z-10 translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-50 rounded-full blur-[100px] -z-10 -translate-x-1/2 translate-y-1/2" />

        <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <Reveal
            direction="right"
            className="order-2 lg:order-1 text-right space-y-8"
          >
            <span className="inline-block bg-orange-100 text-orange-600 px-4 py-1.5 rounded-full text-sm font-bold mb-2">
              ✨ هوشمندترین پلتفرم دوست‌یابی
            </span>
            <h1 className="text-4xl lg:text-6xl font-black text-slate-900 leading-tight">
              با <span className="text-orange-500">هوش مصنوعی</span>، <br />
              هم‌نشین تو پیدا کن
            </h1>
            <p className="text-slate-500 text-lg leading-relaxed max-w-lg">
              ما با استفاده از پیشرفته‌ترین الگوریتم‌های هوش مصنوعی و تست‌های
              روان‌شناسی دقیق، افرادی را پیدا می‌کنیم که بیشترین تفاهم را با شما
              دارند.
            </p>

            <CountdownTimer />

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link href={ctaHref}>
                <button className="flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition shadow-xl hover:shadow-2xl hover:-translate-y-1 w-full sm:w-auto">
                  بزن بریم
                  <ArrowLeft size={20} />
                </button>
              </Link>
              <Link href="/events">
                <button className="bg-white text-slate-700 border-2 border-slate-200 px-8 py-4 rounded-2xl font-bold text-lg hover:border-slate-400 transition w-full sm:w-auto">
                  بیشتر بدانید
                </button>
              </Link>
            </div>

            <div className="flex items-center gap-4 pt-4 text-sm text-slate-500 font-medium">
              <div className="flex -space-x-3 space-x-reverse">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="w-10 h-10 rounded-full border-2 border-white bg-slate-200 overflow-hidden"
                  >
                    <div className="w-full h-full bg-slate-300 flex items-center justify-center text-xs text-slate-500">
                      User
                    </div>
                  </div>
                ))}
                <div className="w-10 h-10 rounded-full border-2 border-white bg-orange-500 flex items-center justify-center text-white text-xs font-bold">
                  +10k
                </div>
              </div>
              <p>
                به جمع{" "}
                <span className="font-bold text-slate-900">۱۰ هزار کاربر</span>{" "}
                فعال ما بپیوندید
              </p>
            </div>
          </Reveal>

          <Reveal direction="left" className="order-1 lg:order-2 relative">
            <div className="relative rounded-[40px] overflow-hidden shadow-2xl shadow-slate-200 border-4 border-white aspect-[4/3] bg-gradient-to-br from-slate-200 to-slate-300">
              <div className="absolute inset-0 flex items-center justify-center bg-slate-100">
                <div className="w-3/4 h-1/4 bg-slate-300 rounded-lg shadow-inner mb-[-100px]" />
                <div className="absolute top-10 w-1/2 h-2 bg-slate-900/10 rounded-full blur-xl" />
              </div>

              <div className="absolute top-8 right-8 bg-white/90 backdrop-blur rounded-2xl p-3 shadow-lg flex items-center gap-3 animate-bounce-slow">
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white">
                  <Check size={20} strokeWidth={4} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold">
                    تطابق یافت شد
                  </p>
                  <p className="text-sm font-black text-slate-900">
                    ۹۸٪ تفاهم اخلاقی
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </Reveal>

      {/* ================= STATS ================= */}
      <Reveal
        as="section"
        direction="left"
        className="bg-slate-900 py-16 text-white relative overflow-hidden"
      >
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8 text-center relative z-10">
          <div>
            <h3 className="text-4xl font-black text-orange-500 mb-2">
              10,000+
            </h3>
            <p className="text-slate-400 font-medium">کاربر فعال</p>
          </div>
          <div>
            <h3 className="text-4xl font-black text-orange-500 mb-2">2,500+</h3>
            <p className="text-slate-400 font-medium">تطابق موفق</p>
          </div>
          <div>
            <h3 className="text-4xl font-black text-orange-500 mb-2">16</h3>
            <p className="text-slate-400 font-medium">تیپ شخصیتی</p>
          </div>
        </div>
        <div className="absolute top-1/2 left-10 w-4 h-4 bg-white rounded-full" />
      </Reveal>

      {/* ================= FLOW ================= */}
      <Reveal as="section" direction="right" className="py-24 px-6 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <span className="text-orange-500 font-bold text-sm tracking-widest uppercase">
              فرآیند ساده
            </span>
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 mt-2 mb-4">
              چگونه هم‌نشین خود را پیدا می‌کنید؟
            </h2>
            <p className="text-slate-500 max-w-2xl mx-auto">
              مسیر پیدا کردن هم‌نشین ایده‌آل شما در ۴ مرحله ساده و علمی طراحی
              شده است تا بهترین تجربه را داشته باشید.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Brain,
                title: "۱. تست روان‌شناسی",
                desc: "پاسخ به سوالات دقیق MBTI و روان‌شناسی برای شناخت بهتر لایه‌های شخصیتی شما.",
              },
              {
                icon: BarChart3,
                title: "۲. تحلیل هوش مصنوعی",
                desc: "الگوریتم‌های پیشرفته ما داده‌های شما را تحلیل کرده و بهترین الگوهای مطابق را می‌یابند.",
              },
              {
                icon: Users,
                title: "۳. تطابق گروهی",
                desc: "عضویت در گروه‌های اختصاصی تلگرام با افرادی که بالاترین درصد تفاهم را با شما دارند.",
              },
              {
                icon: Calendar,
                title: "۴. رویداد حضوری",
                desc: "شرکت در رویدادهای حضوری و بازی‌های گروهی برای تعمیق آشنایی در فضایی امن.",
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-shadow border border-slate-100 group"
              >
                <div className="w-14 h-14 bg-orange-50 text-orange-500 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                  <item.icon size={28} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* ================= SMART ENGINE ================= */}
      <Reveal
        as="section"
        direction="left"
        className="py-24 px-6 overflow-hidden"
      >
        <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="w-14 h-14 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center mb-6">
              <Zap size={28} />
            </div>
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-6 leading-tight">
              موتور هوشمند تطابق شخصیت
            </h2>
            <p className="text-slate-500 text-lg mb-8 leading-relaxed">
              برخلاف روش‌های سنتی، ما فقط به سن و محل زندگی نگاه نمی‌کنیم. موتور
              هوشمند ما با تحلیل ۱۶ تیپ شخصیتی و الگوهای رفتاری، کسانی را به شما
              پیشنهاد می‌دهد که واقعاً با آن‌ها «حرف مشترک» دارید.
            </p>

            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-slate-700 font-medium">
                <CheckCircle2 className="text-green-500" />
                تحلیل عمیق روان‌شناختی
              </li>
              <li className="flex items-center gap-3 text-slate-700 font-medium">
                <CheckCircle2 className="text-green-500" />
                یادگیری مستمر از بازخوردها
              </li>
            </ul>

            <button className="border-2 border-orange-500 text-orange-600 px-8 py-3 rounded-2xl font-bold hover:bg-orange-50 transition">
              درباره هوش مصنوعی
            </button>
          </div>

          <div className="order-1 lg:order-2">
            <div className="bg-slate-900 rounded-[40px] p-8 shadow-2xl relative">
              <div className="flex justify-between items-center mb-8">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <div className="text-slate-500 text-xs font-bold uppercase tracking-widest">
                  داشبورد هوشمند
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-slate-800 p-4 rounded-2xl">
                  <div className="h-20 flex items-end gap-2 justify-between px-2">
                    <div className="w-full bg-orange-500/30 h-[40%] rounded-t" />
                    <div className="w-full bg-orange-500 h-[80%] rounded-t shadow-[0_0_15px_rgba(249,115,22,0.5)]" />
                    <div className="w-full bg-orange-500/50 h-[60%] rounded-t" />
                  </div>
                </div>
                <div className="bg-slate-800 p-4 rounded-2xl flex flex-col justify-center items-center">
                  <div className="text-3xl font-bold text-white mb-1">۱۲۴</div>
                  <div className="text-xs text-slate-400">تعداد تطابق</div>
                </div>
              </div>

              <div className="bg-slate-800 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400 mb-1">
                    احتمال تفاهم
                  </div>
                  <div className="text-2xl font-bold text-orange-500">۹۵٪</div>
                </div>
                <div className="w-12 h-12 rounded-full border-4 border-orange-500 border-t-transparent animate-spin" />
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* ================= TESTIMONIALS ================= */}
      <Reveal
        as="section"
        direction="right"
        className="py-24 px-6 bg-slate-50 overflow-hidden"
      >
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black text-slate-900 mb-4">
              تجربه کاربران راوی
            </h2>
            <p className="text-slate-500">
              ببینید دیگران چگونه هم‌نشین‌های خود را پیدا کردند.
            </p>
          </div>

          <TestimonialsCarousel />
        </div>
      </Reveal>

      {/* ================= CTA ================= */}
      <Reveal as="section" direction="left" className="py-24 px-6">
        <div className="container mx-auto bg-slate-900 text-white rounded-3xl px-8 py-16 relative overflow-hidden">
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-orange-500/30 rounded-full blur-3xl" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
            <div>
              <h2 className="text-3xl font-black mb-4">
                آماده‌ای هم‌نشین خودت را پیدا کنی؟
              </h2>
              <p className="text-slate-300 leading-relaxed">
                با یک تست ۱۵ دقیقه‌ای شروع کن و به جمع ۱۰ هزار نفره راوی اضافه
                شو. تیم ما در کنار توست تا تجربه‌ای امن، علمی و هیجان‌انگیز
                داشته باشی.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-end">
              <Link href={ctaHref}>
                <button className="bg-white text-slate-900 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-100 transition shadow-lg hover:-translate-y-1">
                  بزن بریم
                </button>
              </Link>
              <Link href="/events">
                <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/10 transition">
                  شرکت در رویداد بعدی
                </button>
              </Link>
            </div>
          </div>
        </div>
      </Reveal>

      {/* ================= FAQ ================= */}
      <Reveal as="section" direction="right" className="py-24 px-6 bg-slate-50">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-14">
            <span className="text-orange-500 font-bold text-sm tracking-widest uppercase">
              سوالات متداول
            </span>
            <h2 className="text-3xl font-black text-slate-900 mt-2 mb-4">
              پاسخ به رایج‌ترین پرسش‌ها
            </h2>
            <p className="text-slate-500">
              اگر سوالی داری که اینجا نیست، تیم پشتیبانی ما آماده پاسخگویی است.
            </p>
          </div>

          <div className="space-y-4">
            {faqItems.map((item, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={item.question}
                  className="bg-white border border-slate-200 rounded-2xl shadow-sm"
                >
                  <button
                    onClick={() => handleFaqToggle(index)}
                    className="w-full flex items-center justify-between text-right px-6 py-4"
                  >
                    <span className="text-slate-800 font-bold">
                      {item.question}
                    </span>
                    <ChevronDown
                      className={`transition-transform text-slate-400 ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-6 pb-6 text-sm text-slate-600 leading-relaxed">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* ================= FOOTER ================= */}
      <footer className="bg-slate-900 text-white pt-20 pb-12 px-6">
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-orange-200">
                <Zap size={24} fill="currentColor" />
              </div>
              <span className="text-2xl font-black tracking-tight">راوی</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              راوی با ترکیب تست‌های روان‌شناسی و الگوریتم‌های هوش مصنوعی،
              امن‌ترین مسیر را برای آشنایی و ایجاد روابط عمیق فراهم می‌کند.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">لینک‌های مفید</h4>
            <ul className="space-y-4 text-sm">
              <li>
                <Link href="#" className="hover:text-orange-500 transition">
                  درباره ما
                </Link>
              </li>
              <li>
                <Link href="/test" className="hover:text-orange-500 transition">
                  تست شخصیت‌شناسی
                </Link>
              </li>
              <li>
                <Link
                  href="/events"
                  className="hover:text-orange-500 transition"
                >
                  رویدادها
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-orange-500 transition">
                  قوانین و مقررات
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">تماس با ما</h4>
            <ul className="space-y-4 text-sm">
              <li>info@raavi.ir 📧</li>
              <li>۰۲۱-۸۸۸۸۸۸۸۸ 📞</li>
              <li>تهران، خیابان ولیعصر، برج فناوری 📍</li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">نماد اعتماد</h4>
            <div className="flex gap-4">
              <div className="w-20 h-20 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-center text-xs">
                E-Namad
              </div>
              <div className="w-20 h-20 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-center text-xs">
                Samandehi
              </div>
            </div>
          </div>
        </div>
        <div className="container mx-auto mt-16 pt-8 border-t border-slate-900 text-center text-xs text-slate-600">
          © ۱۴۰۴ راوی. تمامی حقوق محفوظ است.
        </div>
      </footer>
    </div>
  );
}
