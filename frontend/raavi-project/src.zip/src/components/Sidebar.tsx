import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Compass,
  MessageSquare,
  User,
  Zap,
} from "lucide-react";

export default function Sidebar() {
  const pathname = usePathname();

  const menuItems = [
    { name: "داشبورد", icon: LayoutDashboard, path: "/dashboard" },
    { name: "کاوش رویدادها", icon: Compass, path: "/events" }, // مسیر جدید ایونت‌ها
    { name: "چت‌ها", icon: MessageSquare, path: "/chat" },
    { name: "پروفایل کاربری", icon: User, path: "/dashboard/profile" },
  ];

  return (
    <aside className="w-64 bg-[#111827] text-white hidden md:flex flex-col h-screen fixed right-0 top-0 border-l border-slate-800 overflow-y-auto">
      <div className="p-6 border-b border-slate-800">
        <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
          RAAVI
        </h2>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const isActive = pathname === item.path;
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 ${isActive ? "bg-indigo-600 shadow-lg shadow-indigo-900/50 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <item.icon size={20} />
              <span className="font-medium text-sm">{item.name}</span>
            </Link>
          );
        })}

        {/* بخش پیشنهادی */}
        <div className="mt-8 px-4">
          <p className="text-xs font-bold text-slate-500 uppercase mb-4 px-2">
            پیشنهاد ویژه
          </p>
          <div className="bg-gradient-to-br from-indigo-900 to-purple-900 rounded-xl p-4 border border-indigo-500/30">
            <Zap size={20} className="text-yellow-400 mb-2" />
            <p className="text-xs text-indigo-200 mb-3">
              کارگاه ویژه تیم‌سازی اصفهان با ۵۰٪ تخفیف
            </p>
            <button className="w-full py-1.5 bg-white text-indigo-900 text-xs font-bold rounded-lg hover:bg-indigo-50">
              مشاهده
            </button>
          </div>
        </div>
      </nav>
    </aside>
  );
}
