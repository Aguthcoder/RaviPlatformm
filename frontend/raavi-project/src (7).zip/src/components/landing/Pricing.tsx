import ClientShell from "@/components/ClientShell";
import FAQ from "@/components/landing/FAQ";
import Features from "@/components/landing/Features";
import Footer from "@/components/landing/Footer";
import Hero from "@/components/landing/Hero";
import Testimonials from "@/components/landing/Testimonials";
// Pricing component removed

export default function Home() {
  return (
    <ClientShell>
      <main className="min-h-screen bg-slate-50 font-sans">
        <Hero ctaHref="/dashboard/complete-profile" />
        <Features />
        <Testimonials />
        {/* <Pricing /> Removed as requested */}
        <FAQ />
        <Footer />
      </main>
    </ClientShell>
  );
}
