"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Zap } from "lucide-react";

interface HeaderProps {
  isLoggedIn: boolean;
}

export default function Header({ isLoggedIn }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/70 backdrop-blur-lg z-40 border-b border-white/50 h-16 md:h-20 flex items-center shadow-sm">
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 md:w-10 md:h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-lg md:text-xl shadow-lg shadow-orange-200">
            <Zap size={20} className="md:w-6 md:h-6" fill="currentColor" />
          </div>
          <span className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">
            راوی
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-slate-500 font-medium">
          <Link href="/" className="text-orange-600 font-bold">
            خانه
          </Link>
          <Link href="/about" className="hover:text-slate-900 transition">
            درباره ما
          </Link>
          <Link href="/events" className="hover:text-slate-900 transition">
            رویدادها
          </Link>
        </nav>

        <div className="hidden md:flex items-center gap-4">
          {isLoggedIn ? (
            <Link href="/dashboard">
              <button className="bg-slate-900 text-white px-6 py-2.5 rounded-full font-bold hover:bg-slate-800 transition shadow-lg shadow-slate-200">
                ورود به داشبورد
              </button>
            </Link>
          ) : (
            <>
              <Link
                href="/login"
                className="text-slate-600 font-bold hover:text-slate-900"
              >
                ورود
              </Link>
              <Link href="/test">
                <button className="bg-orange-500 text-white px-6 py-2.5 rounded-full font-bold hover:bg-orange-600 transition shadow-lg shadow-orange-200">
                  ثبت نام رایگان
                </button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 text-slate-600"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="absolute top-16 left-0 right-0 bg-white border-b border-slate-100 p-6 flex flex-col gap-4 shadow-xl md:hidden animate-in slide-in-from-top-5">
          <Link 
            href="/" 
            className="text-orange-600 font-bold text-base"
            onClick={() => setMobileMenuOpen(false)}
          >
            خانه
          </Link>
          <Link 
            href="/about" 
            className="font-medium text-slate-700 text-base"
            onClick={() => setMobileMenuOpen(false)}
          >
            درباره ما
          </Link>
          <Link 
            href="/events" 
            className="font-medium text-slate-700 text-base"
            onClick={() => setMobileMenuOpen(false)}
          >
            رویدادها
          </Link>
          {!isLoggedIn && (
            <>
              <Link 
                href="/login" 
                className="font-medium text-slate-700 text-base"
                onClick={() => setMobileMenuOpen(false)}
              >
                ورود
              </Link>
              <Link
                href="/test"
                className="bg-orange-500 text-white text-center py-3 rounded-xl font-bold"
                onClick={() => setMobileMenuOpen(false)}
              >
                شروع کنید
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}
