"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Image as ImageIcon, Smile, MoreVertical } from "lucide-react";

interface Message {
  id: number;
  text: string;
  sender: string;
  isMe: boolean;
  time: string;
  avatar?: string;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "سلام دوستان! کسی برای رویداد جمعه ثبت‌نام کرده؟",
      sender: "Ali",
      isMe: false,
      time: "10:30",
      avatar: "https://i.pravatar.cc/150?u=a",
    },
    {
      id: 2,
      text: "سلام علی جان، بله من و سارا میایم.",
      sender: "Maryam",
      isMe: false,
      time: "10:32",
      avatar: "https://i.pravatar.cc/150?u=b",
    },
    {
      id: 3,
      text: "عالیه! مشتاق دیدارتون هستم.",
      sender: "Me",
      isMe: true,
      time: "10:33",
    },
  ]);

  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMessage: Message = {
      id: Date.now(),
      text: inputText,
      sender: "Me",
      isMe: true,
      time: new Date().toLocaleTimeString("fa-IR", {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    setMessages([...messages, newMessage]);
    setInputText("");
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-hidden">
      {/* Chat Header */}
      <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2 space-x-reverse">
            <img
              src="https://i.pravatar.cc/150?u=a"
              className="w-8 h-8 rounded-full border-2 border-white"
              alt="User"
            />
            <img
              src="https://i.pravatar.cc/150?u=b"
              className="w-8 h-8 rounded-full border-2 border-white"
              alt="User"
            />
            <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-500">
              +12
            </div>
          </div>
          <div>
            <h2 className="font-bold text-slate-900 text-sm md:text-base">
              گروه رویداد تهران
            </h2>
            <p className="text-xs text-slate-500">۱۵ عضو آنلاین</p>
          </div>
        </div>
        <button className="text-slate-400 hover:text-slate-600">
          <MoreVertical size={20} />
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#f0f2f5]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-end gap-2 ${
              msg.isMe ? "flex-row-reverse" : "flex-row"
            }`}
          >
            {!msg.isMe && (
              <img
                src={msg.avatar}
                alt={msg.sender}
                className="w-8 h-8 rounded-full mb-1"
              />
            )}
            <div
              className={`max-w-[75%] md:max-w-[60%] px-4 py-2 rounded-2xl text-sm leading-relaxed relative group ${
                msg.isMe
                  ? "bg-orange-500 text-white rounded-bl-2xl rounded-br-none"
                  : "bg-white text-slate-800 rounded-bl-none rounded-br-2xl shadow-sm"
              }`}
            >
              {!msg.isMe && (
                <div className="text-[10px] font-bold text-orange-600 mb-1">
                  {msg.sender}
                </div>
              )}
              {msg.text}
              <div
                className={`text-[10px] mt-1 flex justify-end ${
                  msg.isMe ? "text-orange-100/80" : "text-slate-400"
                }`}
              >
                {msg.time}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 md:p-4 border-t border-slate-100 bg-white">
        <form
          onSubmit={handleSendMessage}
          className="flex items-center gap-2 bg-slate-100 rounded-2xl p-2 pr-4"
        >
          <button
            type="button"
            className="text-slate-400 hover:text-slate-600 transition"
          >
            <Smile size={24} />
          </button>
          <button
            type="button"
            className="text-slate-400 hover:text-slate-600 transition"
          >
            <ImageIcon size={24} />
          </button>
          <input
            type="text"
            className="flex-1 bg-transparent border-none outline-none text-slate-900 placeholder:text-slate-400 text-sm md:text-base py-2"
            placeholder="پیام خود را بنویسید..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="bg-orange-500 text-white p-3 rounded-xl hover:bg-orange-600 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-orange-200"
          >
            <Send size={20} className={inputText.trim() ? "ml-0.5" : ""} />
          </button>
        </form>
      </div>
    </div>
  );
}
