"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Phone } from "lucide-react";

export default function LoginPage() {
  const [step, setStep] = useState<1 | 2>(1);
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const router = useRouter();

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length >= 10) {
      setStep(2);
    }
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length === 4) {
      router.push("/dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[24px] md:rounded-[32px] p-6 md:p-8 shadow-2xl shadow-slate-200 border border-slate-100">
        <div className="text-center mb-8">
          <Link href="/" className="inline-block mb-6">
            <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white font-bold text-xl mx-auto shadow-lg shadow-orange-200">
              R
            </div>
          </Link>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 mb-2">
            ورود به راوی
          </h1>
          <p className="text-sm md:text-base text-slate-500">
            {step === 1
              ? "برای شروع شماره موبایل خود را وارد کنید"
              : "کد تایید ارسال شده را وارد کنید"}
          </p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleSendOtp} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 block">
                شماره موبایل
              </label>
              <div className="relative">
                <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="tel"
                  placeholder="0912..."
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl px-4 py-3 md:py-4 pr-12 text-left font-bold text-slate-900 focus:outline-none focus:border-orange-500 transition text-base md:text-lg dir-ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  autoFocus
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-orange-500 text-white font-bold py-3 md:py-4 rounded-xl text-base md:text-lg hover:bg-orange-600 transition shadow-lg shadow-orange-200 active:scale-95"
            >
              دریافت کد تایید
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify} className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold text-slate-700">
                  کد تایید
                </label>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs text-orange-500 font-bold hover:underline"
                >
                  ویرایش شماره
                </button>
              </div>
              <input
                type="text"
                maxLength={4}
                className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl px-4 py-3 md:py-4 text-center font-black text-2xl md:text-3xl tracking-[1em] text-slate-900 focus:outline-none focus:border-orange-500 transition"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="w-full bg-slate-900 text-white font-bold py-3 md:py-4 rounded-xl text-base md:text-lg hover:bg-slate-800 transition shadow-lg shadow-slate-200 active:scale-95 flex items-center justify-center gap-2"
            >
              ورود به حساب
              <ArrowLeft size={20} />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
