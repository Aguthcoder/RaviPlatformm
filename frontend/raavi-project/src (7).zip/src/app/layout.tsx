import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google"; // اگر فونت دارید
import "./globals.css";
import ClientShell from "@/components/ClientShell"; // این خط حیاتی است

export const metadata: Metadata = {
  title: "Raavi Platform",
  description: "Platform for AI driven events",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-50 text-slate-900">
        {/* تمام محتوا باید داخل ClientShell باشد تا کانتکست کار کند */}
        <ClientShell>{children}</ClientShell>
      </body>
    </html>
  );
}
