"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAppContext } from "@/context/AppContext"; // مطمئن شوید این مسیر درست است
import Link from "next/link";
import { ArrowRight, Mail, Lock, Eye, EyeOff } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();

  // تلاش برای گرفتن کانتکست با مدیریت خطا
  let dispatch: any;
  try {
    const context = useAppContext();
    dispatch = context.dispatch;
  } catch (error) {
    console.warn("AppContext not found, proceeding without context update");
  }

  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // شبیه‌سازی لاگین و آپدیت کانتکست
      if (dispatch) {
        dispatch({
          type: "SET_USER",
          payload: {
            name: "کاربر عزیز",
            email: formData.email || "user@example.com",
            avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=user",
          },
        });
      }

      // هدایت به داشبورد
      console.log("Redirecting to dashboard...");
      router.push("/dashboard");
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* هدر */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-block mb-4">
            <div className="text-3xl md:text-4xl font-black text-orange-500">
              RAAVI
            </div>
          </Link>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 mb-2">
            خوش آمدید
          </h1>
          <p className="text-sm md:text-base text-slate-600">
            برای ادامه وارد حساب کاربری خود شوید
          </p>
        </div>

        {/* فرم */}
        <div className="bg-white rounded-2xl md:rounded-3xl shadow-xl border border-slate-100 p-6 md:p-8">
          <form onSubmit={handleLogin} className="space-y-5">
            {/* ایمیل */}
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">
                ایمیل
              </label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  className="w-full pr-10 pl-4 py-3 md:py-3.5 text-sm md:text-base border border-slate-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition"
                  placeholder="name@example.com"
                  // required // موقتا غیرفعال برای تست راحت‌تر
                />
              </div>
            </div>

            {/* رمز عبور */}
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">
                رمز عبور
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                  className="w-full pr-10 pl-12 py-3 md:py-3.5 text-sm md:text-base border border-slate-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition"
                  placeholder="••••••••"
                  // required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {/* فراموشی رمز */}
            <div className="text-left">
              <Link
                href="#"
                className="text-xs md:text-sm text-orange-500 hover:text-orange-600 font-medium"
              >
                رمز عبور را فراموش کرده‌اید؟
              </Link>
            </div>

            {/* دکمه ورود */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-orange-500 text-white py-3 md:py-4 rounded-xl font-bold text-sm md:text-base hover:bg-orange-600 transition shadow-lg shadow-orange-200 hover:-translate-y-0.5 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {loading ? "در حال ورود..." : "ورود به حساب کاربری"}
            </button>
          </form>

          {/* ثبت نام */}
          <div className="mt-6 text-center">
            <p className="text-xs md:text-sm text-slate-600">
              حساب کاربری ندارید؟{" "}
              <Link
                href="/register"
                className="text-orange-500 hover:text-orange-600 font-bold"
              >
                ثبت‌نام کنید
              </Link>
            </p>
          </div>
        </div>

        {/* بازگشت */}
        <Link
          href="/"
          className="flex items-center justify-center gap-2 mt-6 text-sm text-slate-600 hover:text-slate-900 transition"
        >
          <ArrowRight size={16} />
          بازگشت به صفحه اصلی
        </Link>
      </div>
    </div>
  );
}
