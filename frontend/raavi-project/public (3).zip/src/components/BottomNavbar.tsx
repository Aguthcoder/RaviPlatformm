"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  User,
  Gamepad2,
  Bell,
  Calendar,
} from "lucide-react";

export default function BottomNavbar() {
  const pathname = usePathname();

  const navItems = [
    {
      href: "/dashboard/profile",
      label: "پروفایل",
      icon: User,
    },
    {
      href: "/dashboard/games",
      label: "بازی",
      icon: Gamepad2,
    },
    {
      href: "/dashboard/notifications",
      label: "اعلان‌ها",
      icon: Bell,
    },
    {
      href: "/events",
      label: "رزرو",
      icon: Calendar,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-lg">
      <div className="max-w-screen-xl mx-auto">
        <div className="flex items-center justify-around px-4 py-3">
          {navItems.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center gap-1 min-w-[60px] transition-all ${
                  isActive
                    ? "text-raavi-orange"
                    : "text-slate-600 hover:text-raavi-orange"
                }`}
              >
                <div
                  className={`p-2 rounded-xl transition-all ${
                    isActive ? "bg-raavi-50" : "hover:bg-slate-100"
                  }`}
                >
                  <Icon
                    size={22}
                    className={isActive ? "stroke-[2.5]" : "stroke-[2]"}
                  />
                </div>
                <span className={`text-xs font-bold ${isActive ? "" : "font-medium"}`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
