"use client";

import { useEffect, useState } from "react";

interface LoadingScreenProps {
  message?: string;
}

export default function LoadingScreen({ message }: LoadingScreenProps) {
  const [dots, setDots] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setDots((prev) => (prev.length >= 3 ? "" : prev + "."));
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy-800">
      {/* Background Animated Blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 -left-20 w-[500px] h-[500px] bg-raavi-500/10 rounded-full mix-blend-multiply filter blur-[80px] animate-blob"></div>
        <div className="absolute top-0 -right-20 w-[400px] h-[400px] bg-raavi-400/10 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-0 -left-20 w-[400px] h-[400px] bg-raavi-300/10 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 text-center">
        {/* لوگو و نوشته Raavi */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <h1 className="text-5xl md:text-6xl font-black text-raavi-orange font-estedad">
            Raavi
          </h1>
          <span className="text-5xl md:text-6xl font-black text-raavi-orange">
            {dots}
          </span>
        </div>

        {message && (
          <p className="text-slate-300 text-lg font-medium mt-4">{message}</p>
        )}
      </div>
    </div>
  );
}
