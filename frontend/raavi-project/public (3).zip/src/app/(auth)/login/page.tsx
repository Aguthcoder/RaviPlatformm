"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAppContext } from "@/context/AppContext";
import Link from "next/link";
import { Mail, Phone, ArrowRight } from "lucide-react";
import LoadingScreen from "@/components/LoadingScreen";
import BackgroundBlobs from "@/components/BackgroundBlobs";

type LoginMethod = "email" | "phone";

export default function LoginPage() {
  const router = useRouter();
  const { dispatch } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [loginMethod, setLoginMethod] = useState<LoginMethod>("phone");
  const [formData, setFormData] = useState({
    emailOrPhone: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // شبیه‌سازی ارسال کد
    await new Promise((resolve) => setTimeout(resolve, 1500));

    if (loginMethod === "phone") {
      router.push(`/login/verify?phone=${formData.emailOrPhone}`);
    } else {
      // برای ایمیل، مستقیماً login می‌کنیم
      dispatch({ type: "LOGIN" });
      router.push("/test");
    }
  };

  if (loading) {
    return <LoadingScreen message="در حال ارسال کد تایید..." />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <BackgroundBlobs />

      <div className="w-full max-w-md relative z-10">
        {/* لوگو و برگشت */}
        <div className="text-center mb-8">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-slate-600 hover:text-navy-800 mb-4 transition"
          >
            <ArrowRight size={18} />
            <span className="font-medium">بازگشت به صفحه اصلی</span>
          </Link>
          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            خوش آمدید
          </h1>
          <p className="text-slate-600">
            برای ورود، {loginMethod === "phone" ? "شماره موبایل" : "ایمیل"} خود
            را وارد کنید
          </p>
        </div>

        {/* فرم */}
        <div className="bg-navy-800 rounded-3xl shadow-2xl border border-navy-700 p-8">
          {/* انتخاب روش ورود */}
          <div className="flex gap-2 mb-6 bg-navy-900 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => setLoginMethod("phone")}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                loginMethod === "phone"
                  ? "bg-raavi-orange text-white"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              شماره موبایل
            </button>
            <button
              type="button"
              onClick={() => setLoginMethod("email")}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                loginMethod === "email"
                  ? "bg-raavi-orange text-white"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              ایمیل
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* ایمیل یا شماره */}
            <div>
              <label className="block text-raavi-orange font-bold mb-2">
                {loginMethod === "phone" ? "شماره موبایل" : "ایمیل"}
              </label>
              <div className="relative">
                {loginMethod === "phone" ? (
                  <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                ) : (
                  <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                )}
                <input
                  type={loginMethod === "phone" ? "tel" : "email"}
                  value={formData.emailOrPhone}
                  onChange={(e) =>
                    setFormData({ ...formData, emailOrPhone: e.target.value })
                  }
                  placeholder={
                    loginMethod === "phone"
                      ? "09123456789"
                      : "example@email.com"
                  }
                  className="w-full pr-12 pl-4 py-4 rounded-2xl bg-navy-900 border-2 border-navy-700 focus:border-raavi-orange outline-none transition text-white placeholder:text-slate-500"
                  required
                  dir={loginMethod === "phone" ? "ltr" : "ltr"}
                />
              </div>
            </div>

            {/* دکمه ورود */}
            <button
              type="submit"
              className="w-full bg-raavi-orange hover:bg-raavi-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-raavi-500/30 transition-all hover:-translate-y-1"
            >
              {loginMethod === "phone" ? "دریافت کد تایید" : "ورود"}
            </button>
          </form>
        </div>

        {/* توضیحات */}
        <p className="text-center text-slate-600 mt-6 text-sm">
          با ورود به راوی، شما{" "}
          <Link href="/terms" className="text-raavi-orange hover:underline">
            قوانین و مقررات
          </Link>{" "}
          را می‌پذیرید.
        </p>
      </div>
    </div>
  );
}
