"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAppContext } from "@/context/AppContext";
import { ArrowRight } from "lucide-react";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import LoadingScreen from "@/components/LoadingScreen";

// سوالات تست با slider
const questions = [
  {
    id: 1,
    text: "من استرسی هستم",
    leftLabel: "کاملا موافق",
    rightLabel: "کاملا مخالف",
  },
  {
    id: 2,
    text: "من اجتماعی هستم",
    leftLabel: "کاملا موافق",
    rightLabel: "کاملا مخالف",
  },
  {
    id: 3,
    text: "من آدم باز و دوستانه ای هستم",
    leftLabel: "کاملا موافق",
    rightLabel: "کاملا مخالف",
  },
  {
    id: 4,
    text: "من خلاق و هنرمند هستم",
    leftLabel: "کاملا موافق",
    rightLabel: "کاملا مخالف",
  },
  {
    id: 5,
    text: "من کنجکاو و پرسشگر هستم",
    leftLabel: "کاملا موافق",
    rightLabel: "کاملا مخالف",
  },
];

export default function TestPage() {
  const router = useRouter();
  const { dispatch } = useAppContext();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>(new Array(questions.length).fill(3));
  const [loading, setLoading] = useState(false);
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleSliderChange = (value: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = value;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1);
    }
  };

  const handleFinish = async () => {
    setLoading(true);
    
    // شبیه‌سازی ذخیره نتایج
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    dispatch({ type: "COMPLETE_TEST" });
    router.push("/dashboard");
  };

  if (loading) {
    return <LoadingScreen message="در حال پردازش نتایج..." />;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative pb-24">
      <BackgroundBlobs />

      <div className="w-full max-w-2xl relative z-10">
        {/* هدر */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            من استرسی هستم
          </h1>
          <p className="text-slate-600">
            برای ما بگو که چقدر این جمله درباره‌ات صادق است
          </p>
        </div>

        {/* نوار پیشرفت */}
        <div className="mb-8">
          <div className="flex justify-between text-sm font-bold text-slate-600 mb-2">
            <span>پیشرفت</span>
            <span className="text-raavi-orange">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-navy-200 rounded-full h-3 overflow-hidden">
            <div
              className="bg-raavi-orange h-3 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* کارت سوال */}
        <div className="bg-navy-800 rounded-3xl shadow-2xl border border-navy-700 p-8 md:p-12">
          <div className="mb-12">
            <h2 className="text-3xl font-black text-white mb-2 text-center font-estedad">
              {questions[currentQuestion].text}
            </h2>
          </div>

          {/* Slider */}
          <div className="space-y-6">
            <div className="relative px-2">
              {/* Labels */}
              <div className="flex justify-between text-sm font-bold mb-4">
                <span className="text-raavi-orange">
                  {questions[currentQuestion].leftLabel}
                </span>
                <span className="text-white">
                  {questions[currentQuestion].rightLabel}
                </span>
              </div>

              {/* Custom Slider */}
              <div className="relative h-2 bg-navy-900 rounded-full">
                {/* Track */}
                <div
                  className="absolute h-2 bg-raavi-orange rounded-full transition-all"
                  style={{ width: `${(answers[currentQuestion] / 5) * 100}%` }}
                ></div>

                {/* Thumb */}
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={answers[currentQuestion]}
                  onChange={(e) => handleSliderChange(Number(e.target.value))}
                  className="absolute w-full h-2 appearance-none bg-transparent cursor-pointer z-10"
                  style={{
                    WebkitAppearance: "none",
                  }}
                />
                
                <style jsx>{`
                  input[type="range"]::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    appearance: none;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    background: #FF6B35;
                    cursor: pointer;
                    box-shadow: 0 2px 8px rgba(255, 107, 53, 0.5);
                  }

                  input[type="range"]::-moz-range-thumb {
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    background: #FF6B35;
                    cursor: pointer;
                    border: none;
                    box-shadow: 0 2px 8px rgba(255, 107, 53, 0.5);
                  }
                `}</style>
              </div>

              {/* Numbers */}
              <div className="flex justify-between mt-2 px-1">
                {[1, 2, 3, 4, 5].map((num) => (
                  <span
                    key={num}
                    className={`text-sm font-bold ${
                      answers[currentQuestion] === num
                        ? "text-raavi-orange"
                        : "text-slate-500"
                    }`}
                  >
                    {num}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* دکمه‌های کنترل */}
        <div className="mt-8 flex justify-between items-center">
          <button
            onClick={handleBack}
            disabled={currentQuestion === 0}
            className="px-6 py-3 text-slate-600 hover:text-navy-900 font-bold disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2 transition"
          >
            <ArrowRight size={20} /> قبلی
          </button>

          <span className="text-slate-600 font-bold">
            {currentQuestion + 1} / {questions.length}
          </span>

          <button
            onClick={handleNext}
            className="px-8 py-3.5 bg-raavi-orange hover:bg-raavi-600 text-white font-bold rounded-2xl shadow-lg shadow-raavi-500/30 transition-all hover:-translate-y-1 flex items-center gap-2"
          >
            {currentQuestion === questions.length - 1 ? "اتمام" : "بعدی"}
          </button>
        </div>
      </div>
    </div>
  );
}
