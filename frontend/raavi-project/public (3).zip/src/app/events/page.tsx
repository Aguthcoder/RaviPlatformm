"use client";

import { useRouter } from "next/navigation";
import { MessageCircle, Users, Footprints, Heart, GraduationCap, Briefcase, Lightbulb, Dumbbell, Home } from "lucide-react";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import BottomNavbar from "@/components/BottomNavbar";

interface Category {
  id: string;
  title: string;
  icon: typeof Users;
  active: boolean;
  color: string;
}

const categories: Category[] = [
  {
    id: "hamnesheen",
    title: "همنشین",
    icon: Users,
    active: true,
    color: "bg-blue-500",
  },
  {
    id: "hamsohbat",
    title: "هم‌صحبت",
    icon: MessageCircle,
    active: true,
    color: "bg-blue-500",
  },
  {
    id: "hampa",
    title: "همپا",
    icon: Footprints,
    active: true,
    color: "bg-blue-500",
  },
  {
    id: "hamya",
    title: "همیا",
    icon: Heart,
    active: false,
    color: "bg-green-500",
  },
  {
    id: "hamamouz",
    title: "هم آموز",
    icon: GraduationCap,
    active: false,
    color: "bg-blue-400",
  },
  {
    id: "hamkar",
    title: "همکار",
    icon: Briefcase,
    active: false,
    color: "bg-blue-500",
  },
  {
    id: "hamfekar",
    title: "همفکر",
    icon: Lightbulb,
    active: false,
    color: "bg-blue-500",
  },
  {
    id: "hamtamreen",
    title: "همتمرین",
    icon: Dumbbell,
    active: false,
    color: "bg-blue-500",
  },
  {
    id: "hamkhane",
    title: "همخانه",
    icon: Home,
    active: false,
    color: "bg-blue-500",
  },
];

export default function EventsPage() {
  const router = useRouter();

  const handleCategoryClick = (category: Category) => {
    if (category.active) {
      router.push(`/events/category/${category.id}`);
    } else {
      // نمایش پیام پیش‌رزرو
      alert(`این دسته هنوز فعال نیست. می‌توانید برای ${category.title} پیش‌رزرو کنید.`);
    }
  };

  return (
    <div className="min-h-screen pb-24 pt-8 px-4 relative">
      <BackgroundBlobs />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-black text-navy-900 mb-2 font-estedad">
            دسته بندی
          </h1>
          <p className="text-slate-600 text-lg">
            دسته مورد نظرت رو انتخاب کن
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {categories.map((category) => {
            const Icon = category.icon;
            
            return (
              <button
                key={category.id}
                onClick={() => handleCategoryClick(category)}
                className={`relative bg-white rounded-3xl p-8 transition-all duration-300 hover:-translate-y-1 ${
                  category.active
                    ? "shadow-xl hover:shadow-2xl border-2 border-transparent hover:border-raavi-orange"
                    : "opacity-60 shadow-lg"
                }`}
                disabled={!category.active}
              >
                {/* Icon Container */}
                <div className="flex flex-col items-center gap-4">
                  <div className={`w-20 h-20 ${category.color} rounded-full flex items-center justify-center`}>
                    <Icon className="text-white" size={36} strokeWidth={2} />
                  </div>

                  {/* Title */}
                  <h3 className="text-navy-900 font-black text-xl font-estedad">
                    {category.title}
                  </h3>
                </div>

                {/* Inactive Badge */}
                {!category.active && (
                  <div className="absolute top-4 right-4 bg-red-100 text-red-600 text-xs font-bold px-3 py-1 rounded-full">
                    به زودی
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Info Banner */}
        <div className="mt-12 bg-navy-800 rounded-3xl p-6 text-center">
          <h3 className="text-raavi-orange font-bold text-lg mb-2">
            دسته‌های غیرفعال
          </h3>
          <p className="text-white text-sm">
            دسته‌های غیرفعال را می‌توانید پیش‌رزرو کنید. با رسیدن تعداد مورد نیاز، همنشینی فعال می‌شود و به شما اطلاع می‌دهیم.
          </p>
        </div>
      </div>

      <BottomNavbar />
    </div>
  );
}
