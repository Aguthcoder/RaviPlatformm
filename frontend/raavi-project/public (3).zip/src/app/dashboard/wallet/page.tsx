"use client";

import { useState } from "react";
import { ArrowRight, Wallet, Plus, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { useRouter } from "next/navigation";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import BottomNavbar from "@/components/BottomNavbar";

interface Transaction {
  id: string;
  type: "charge" | "payment";
  amount: number;
  description: string;
  date: string;
}

const sampleTransactions: Transaction[] = [
  {
    id: "1",
    type: "charge",
    amount: 500000,
    description: "شارژ کیف پول",
    date: "۱۴۰۴/۰۲/۱۸",
  },
  {
    id: "2",
    type: "payment",
    amount: 75000,
    description: "رزرو همنشینی: کافه و گپ‌زدن",
    date: "۱۴۰۴/۰۲/۱۷",
  },
  {
    id: "3",
    type: "payment",
    amount: 50000,
    description: "رزرو همنشینی: قدم زدن در پارک",
    date: "۱۴۰۴/۰۲/۱۵",
  },
];

export default function WalletPage() {
  const router = useRouter();
  const [balance] = useState(375000);
  const [showChargeModal, setShowChargeModal] = useState(false);
  const [chargeAmount, setChargeAmount] = useState("");

  const quickAmounts = [50000, 100000, 200000, 500000];

  const handleCharge = () => {
    if (chargeAmount) {
      alert(`درحال انتقال به درگاه پرداخت برای شارژ ${parseInt(chargeAmount).toLocaleString("fa-IR")} تومان`);
      setShowChargeModal(false);
      setChargeAmount("");
    }
  };

  return (
    <div className="min-h-screen pb-24 pt-8 px-4 relative">
      <BackgroundBlobs />

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-slate-600 hover:text-navy-900 mb-4 transition"
          >
            <ArrowRight size={20} />
            <span className="font-medium">بازگشت</span>
          </button>

          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            کیف پول
          </h1>
          <p className="text-slate-600">مدیریت موجودی و تراکنش‌های خود</p>
        </div>

        {/* Balance Card */}
        <div className="bg-gradient-to-br from-raavi-orange to-raavi-600 rounded-3xl p-8 mb-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-6">
            <Wallet className="text-white" size={32} />
            <h2 className="text-white text-xl font-bold">موجودی کیف پول</h2>
          </div>

          <div className="mb-8">
            <span className="text-white text-5xl font-black font-estedad">
              {balance.toLocaleString("fa-IR")}
            </span>
            <span className="text-white/80 text-xl mr-2">تومان</span>
          </div>

          <button
            onClick={() => setShowChargeModal(true)}
            className="bg-white text-raavi-orange font-bold py-3 px-8 rounded-2xl hover:bg-slate-50 transition-all hover:-translate-y-1 flex items-center gap-2 shadow-lg"
          >
            <Plus size={20} />
            شارژ کیف پول
          </button>
        </div>

        {/* Transactions */}
        <div className="bg-white rounded-3xl p-8 shadow-lg">
          <h2 className="text-2xl font-black text-navy-900 mb-6 font-estedad">
            تراکنش‌های اخیر
          </h2>

          <div className="space-y-4">
            {sampleTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition"
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      transaction.type === "charge"
                        ? "bg-green-100"
                        : "bg-red-100"
                    }`}
                  >
                    {transaction.type === "charge" ? (
                      <ArrowDownRight className="text-green-600" size={24} />
                    ) : (
                      <ArrowUpRight className="text-red-600" size={24} />
                    )}
                  </div>

                  <div>
                    <h3 className="font-bold text-navy-900">
                      {transaction.description}
                    </h3>
                    <p className="text-slate-500 text-sm">{transaction.date}</p>
                  </div>
                </div>

                <div>
                  <span
                    className={`text-xl font-black font-estedad ${
                      transaction.type === "charge"
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {transaction.type === "charge" ? "+" : "-"}
                    {transaction.amount.toLocaleString("fa-IR")}
                  </span>
                  <span className="text-slate-400 text-sm mr-1">تومان</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charge Modal */}
      {showChargeModal && (
        <div className="fixed inset-0 bg-navy-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full">
            <h2 className="text-2xl font-black text-navy-900 mb-6 font-estedad">
              شارژ کیف پول
            </h2>

            {/* Quick Amounts */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              {quickAmounts.map((amount) => (
                <button
                  key={amount}
                  onClick={() => setChargeAmount(amount.toString())}
                  className={`py-3 rounded-2xl font-bold transition-all ${
                    chargeAmount === amount.toString()
                      ? "bg-raavi-orange text-white"
                      : "bg-slate-100 text-navy-900 hover:bg-slate-200"
                  }`}
                >
                  {amount.toLocaleString("fa-IR")} تومان
                </button>
              ))}
            </div>

            {/* Custom Amount */}
            <div className="mb-6">
              <label className="block text-navy-900 font-bold mb-2">
                مبلغ دلخواه (تومان)
              </label>
              <input
                type="number"
                value={chargeAmount}
                onChange={(e) => setChargeAmount(e.target.value)}
                placeholder="مبلغ را وارد کنید"
                className="w-full px-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-raavi-orange outline-none transition"
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => setShowChargeModal(false)}
                className="flex-1 py-3 bg-slate-100 text-navy-900 font-bold rounded-2xl hover:bg-slate-200 transition"
              >
                انصراف
              </button>
              <button
                onClick={handleCharge}
                disabled={!chargeAmount}
                className="flex-1 py-3 bg-raavi-orange text-white font-bold rounded-2xl hover:bg-raavi-600 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                پرداخت
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNavbar />
    </div>
  );
}
