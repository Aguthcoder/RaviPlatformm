"use client";

import { useState } from "react";
import { ArrowRight, Share2, Copy, Check } from "lucide-react";
import { useRouter } from "next/navigation";
import BackgroundBlobs from "@/components/BackgroundBlobs";
import BottomNavbar from "@/components/BottomNavbar";

export default function InvitePage() {
  const router = useRouter();
  const [copied, setCopied] = useState(false);
  const inviteCode = "RAAVI2025";
  const inviteLink = `https://raavi.ir/invite/${inviteCode}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "دعوت به راوی",
        text: "به جمع همنشین‌های راوی بپیوند!",
        url: inviteLink,
      });
    }
  };

  return (
    <div className="min-h-screen pb-24 pt-8 px-4 relative">
      <BackgroundBlobs />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-slate-600 hover:text-navy-900 mb-4 transition"
          >
            <ArrowRight size={20} />
            <span className="font-medium">بازگشت</span>
          </button>

          <h1 className="text-4xl font-black text-navy-900 mb-2 font-estedad">
            دعوت از دوستان
          </h1>
          <p className="text-slate-600">
            دوستانت رو به راوی دعوت کن و پاداش بگیر!
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-gradient-to-br from-raavi-orange to-raavi-600 rounded-3xl p-8 mb-8 shadow-2xl text-white">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">🎁</div>
            <h2 className="text-3xl font-black mb-2 font-estedad">
              ۵۰,۰۰۰ تومان پاداش
            </h2>
            <p className="text-white/80">
              برای هر دوستی که با لینک دعوت شما ثبت‌نام کند
            </p>
          </div>

          {/* Invite Code */}
          <div className="bg-white/10 backdrop-blur rounded-2xl p-6 mb-6">
            <p className="text-white/80 text-sm mb-2">کد دعوت شما</p>
            <p className="text-3xl font-black font-estedad">{inviteCode}</p>
          </div>

          {/* Invite Link */}
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4 mb-6">
            <p className="text-white/80 text-sm mb-2">لینک دعوت</p>
            <div className="flex items-center gap-2">
              <p className="flex-1 text-white font-mono text-sm truncate">
                {inviteLink}
              </p>
              <button
                onClick={handleCopy}
                className="bg-white text-raavi-orange p-3 rounded-xl hover:bg-slate-100 transition"
              >
                {copied ? <Check size={20} /> : <Copy size={20} />}
              </button>
            </div>
          </div>

          {/* Share Button */}
          <button
            onClick={handleShare}
            className="w-full bg-white text-raavi-orange font-bold py-4 rounded-2xl hover:bg-slate-50 transition-all hover:-translate-y-1 flex items-center justify-center gap-2 shadow-lg"
          >
            <Share2 size={20} />
            اشتراک‌گذاری لینک دعوت
          </button>
        </div>

        {/* How it works */}
        <div className="bg-white rounded-3xl p-8 shadow-lg">
          <h2 className="text-2xl font-black text-navy-900 mb-6 font-estedad">
            چطور کار می‌کنه؟
          </h2>

          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-raavi-orange rounded-xl flex items-center justify-center text-white font-black text-xl flex-shrink-0">
                ۱
              </div>
              <div>
                <h3 className="font-bold text-navy-900 mb-1">
                  لینک رو به اشتراک بذار
                </h3>
                <p className="text-slate-600 text-sm">
                  لینک دعوت خودت رو با دوستات به اشتراک بذار
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 bg-raavi-orange rounded-xl flex items-center justify-center text-white font-black text-xl flex-shrink-0">
                ۲
              </div>
              <div>
                <h3 className="font-bold text-navy-900 mb-1">
                  دوستت ثبت‌نام کنه
                </h3>
                <p className="text-slate-600 text-sm">
                  وقتی دوستت با لینک تو ثبت‌نام کنه و اولین همنشینی رو رزرو کنه
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 bg-raavi-orange rounded-xl flex items-center justify-center text-white font-black text-xl flex-shrink-0">
                ۳
              </div>
              <div>
                <h3 className="font-bold text-navy-900 mb-1">پاداش بگیر!</h3>
                <p className="text-slate-600 text-sm">
                  هم تو و هم دوستت ۵۰,۰۰۰ تومان اعتبار دریافت می‌کنید
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mt-8">
          <div className="bg-navy-800 rounded-2xl p-6 text-center">
            <p className="text-4xl font-black text-raavi-orange mb-2 font-estedad">
              ۰
            </p>
            <p className="text-white text-sm">دعوت موفق</p>
          </div>
          <div className="bg-navy-800 rounded-2xl p-6 text-center">
            <p className="text-4xl font-black text-raavi-orange mb-2 font-estedad">
              ۰
            </p>
            <p className="text-white text-sm">پاداش دریافتی</p>
          </div>
        </div>
      </div>

      <BottomNavbar />
    </div>
  );
}
