import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
        },
        // رنگ نارنجی یکسان برای تمام سایت
        raavi: {
          orange: '#FF6B35', // رنگ نارنجی فوکس
          50: '#fff5f2',
          100: '#ffe8e0',
          200: '#ffd4c5',
          300: '#ffb59d',
          400: '#ff8b67',
          500: '#FF6B35',
          600: '#f04f1a',
          700: '#c93e12',
          800: '#a43415',
          900: '#872f17',
        },
        // رنگ سورمه‌ای
        navy: {
          50: '#f0f4f8',
          100: '#d9e2ec',
          200: '#b8c5d4',
          300: '#90a4b8',
          400: '#6b8099',
          500: '#4f5d73',
          600: '#3d4a5c',
          700: '#2d3748',
          800: '#1a202c',
          900: '#0f1419',
        },
      },
      fontFamily: {
        sans: ['Estedad', 'Vazirmatn', 'Tanha', 'system-ui', 'sans-serif'],
        vazir: ['Vazirmatn', 'sans-serif'],
        estedad: ['Estedad', 'sans-serif'],
        tanha: ['Tanha', 'sans-serif'],
      },
      animation: {
        'bounce-slow': 'bounce-slow 3s ease-in-out infinite',
        'blob': 'blob 7s infinite',
        'shake': 'shake 0.4s ease-in-out',
      },
      keyframes: {
        'bounce-slow': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' },
        },
        'blob': {
          '0%': { transform: 'translate(0px, 0px) scale(1)' },
          '33%': { transform: 'translate(30px, -50px) scale(1.1)' },
          '66%': { transform: 'translate(-20px, 20px) scale(0.9)' },
          '100%': { transform: 'translate(0px, 0px) scale(1)' },
        },
        'shake': {
          '0%, 100%': { transform: 'translateX(0)' },
          '20%': { transform: 'translateX(-2px)' },
          '40%': { transform: 'translateX(2px)' },
          '60%': { transform: 'translateX(-2px)' },
          '80%': { transform: 'translateX(2px)' },
        },
      },
    },
  },
  plugins: [],
}

export default config
