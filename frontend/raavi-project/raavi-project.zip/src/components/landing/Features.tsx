"use client";

import { Brain, BarChart3, Users, Calendar } from "lucide-react";
import Reveal from "../Reveal";

const features = [
  {
    icon: Brain,
    title: "تست روانشناسی علمی",
    description:
      "ما تیپ شخصیتی و سبک زندگی شما را با استفاده از آزمون‌های معتبر شناسایی می‌کنیم.",
  },
  {
    icon: BarChart3,
    title: "الگوریتم پیشرفته",
    description:
      "الگوریتم هوش مصنوعی راوی با تحلیل داده‌های گسترده، بهترین هم‌نشین را به شما معرفی می‌کند.",
  },
  {
    icon: Users,
    title: "رویدادهای تخصصی",
    description:
      "در رویدادهای گروهی حضوری یا آنلاین شرکت کنید و دوستان جدید پیدا کنید.",
  },
  {
    icon: Calendar,
    title: "پیگیری و بازخورد",
    description:
      "بعد از هر رویداد نظرات خود را ثبت کنید تا الگوریتم پیشنهادات بهتری ارائه دهد.",
  },
];

export default function Features() {
  return (
    <Reveal
      as="section"
      direction="left"
      className="py-16 md:py-24 px-4 md:px-6 bg-white/40 backdrop-blur-sm"
    >
      <div className="container mx-auto relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <span className="text-orange-500 font-bold text-xs md:text-sm tracking-widest uppercase">
            چطور کار می‌کند؟
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 mt-2 mb-4">
            مسیر آشنایی در راوی
          </h2>
          <p className="text-slate-500 text-sm md:text-base max-w-2xl mx-auto">
            با ۴ قدم ساده، با افرادی که واقعا با شما جور هستند، آشنا شوید.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Reveal key={feature.title} direction="up" delay={index * 0.1}>
                <div className="group relative bg-white rounded-2xl md:rounded-3xl p-6 md:p-8 border border-slate-200 hover:border-orange-200 transition-all hover:shadow-xl hover:shadow-orange-100/50 hover:-translate-y-2">
                  <div className="absolute -top-4 -right-4 w-12 h-12 md:w-14 md:h-14 bg-orange-500 rounded-2xl flex items-center justify-center text-white font-black text-base md:text-lg shadow-lg shadow-orange-200 group-hover:scale-110 transition-transform">
                    {index + 1}
                  </div>
                  <div className="w-12 h-12 md:w-14 md:h-14 bg-orange-100 rounded-xl md:rounded-2xl flex items-center justify-center mb-4 md:mb-6 group-hover:bg-orange-500 transition-colors">
                    <Icon className="text-orange-500 group-hover:text-white transition-colors w-6 h-6 md:w-7 md:h-7" />
                  </div>
                  <h3 className="text-base md:text-lg font-bold text-slate-900 mb-2 md:mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-xs md:text-sm text-slate-500 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </Reveal>
  );
}
