"use client";

import { useEffect, useMemo, useState } from "react";

type TimeLeft = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
};

function Circle({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="bg-orange-500 text-white w-14 h-14 md:w-16 md:h-16 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/30">
        <span className="font-bold text-lg md:text-xl tabular-nums">
          {String(value).padStart(2, "0")}
        </span>
      </div>
      <span className="text-xs md:text-sm font-medium text-slate-600">
        {label}
      </span>
    </div>
  );
}

export default function CountdownTimer({
  target,
}: {
  target?: number | string | Date;
}) {
  const targetTime = useMemo(() => {
    if (!target) return Date.now() + 3 * 24 * 60 * 60 * 1000;
    if (typeof target === "number") return target;
    if (target instanceof Date) return target.getTime();
    return new Date(target).getTime();
  }, [target]);

  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const tick = () => {
      const diff = targetTime - Date.now();

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <div className="flex flex-row-reverse items-center gap-4 md:gap-6">
      <Circle value={timeLeft.days} label="روز" />
      <Circle value={timeLeft.hours} label="ساعت" />
      <Circle value={timeLeft.minutes} label="دقیقه" />
      <Circle value={timeLeft.seconds} label="ثانیه" />
    </div>
  );
}
